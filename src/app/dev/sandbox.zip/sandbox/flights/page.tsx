"use client";

import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { useRouter } from "next/navigation";

type Player = {
  id: string;
  name: string;
  handicap: number;
  quartile: number;
};

type Flight = {
  id: string;
  index: number;
  players: Player[];
  isManual: boolean;
};

// Simple LCG PRNG
class PRNG {
  private seed: number;

  constructor(seed: number) {
    this.seed = seed;
  }

  next(): number {
    this.seed = (this.seed * 1664525 + 1013904223) % 2 ** 32;
    return this.seed / 2 ** 32;
  }

  nextInt(min: number, max: number): number {
    return Math.floor(this.next() * (max - min + 1)) + min;
  }

  nextFloat(min: number, max: number): number {
    return this.next() * (max - min) + min;
  }
}

const firstNames = [
  "Alex", "Jordan", "Sam", "Taylor", "Casey", "Morgan", "Riley", "Avery",
  "Cameron", "Dakota", "Quinn", "Sage", "River", "Phoenix", "Blake", "Hayden",
  "Jamie", "Reese", "Rowan", "Skyler", "Finley", "Emery", "Drew", "Kai",
  "Noah", "Liam", "Emma", "Olivia", "James", "William", "Benjamin", "Henry",
  "Charlotte", "Amelia", "Sophia", "Isabella", "Mason", "Ethan", "Lucas", "Alexander"
];

const lastNames = [
  "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis",
  "Rodriguez", "Martinez", "Hernandez", "Lopez", "Wilson", "Anderson", "Thomas", "Taylor",
  "Moore", "Jackson", "Martin", "Lee", "Thompson", "White", "Harris", "Sanchez",
  "Clark", "Ramirez", "Lewis", "Robinson", "Walker", "Young", "Allen", "King",
  "Wright", "Scott", "Torres", "Nguyen", "Hill", "Flores", "Green", "Adams"
];

function generatePlayers(seed: number, count: number): Player[] {
  const rng = new PRNG(seed);
  const players: Player[] = [];

  for (let i = 0; i < count; i++) {
    const firstName = firstNames[rng.nextInt(0, firstNames.length - 1)];
    const lastName = lastNames[rng.nextInt(0, lastNames.length - 1)];
    const name = `${firstName} ${lastName}`;

    // Generate handicap with 3 clusters covering 1.0-36.0
    const cluster = rng.nextInt(0, 2);
    let handicap: number;
    
    // Approximate gaussian using sum of uniforms
    const u1 = rng.next();
    const u2 = rng.next();
    const u3 = rng.next();
    const u4 = rng.next();
    const u5 = rng.next();
    const u6 = rng.next();
    const g = (u1 + u2 + u3 + u4 + u5 + u6) - 3; // roughly normal-ish, centered at 0
    
    if (cluster === 0) {
      // Low handicap cluster: mean ~7, spread ~4 (range ~1-15)
      handicap = 7 + g * 4;
    } else if (cluster === 1) {
      // Mid handicap cluster: mean ~16, spread ~5 (range ~6-26)
      handicap = 16 + g * 5;
    } else {
      // High handicap cluster: mean ~27, spread ~6 (range ~15-36)
      handicap = 27 + g * 6;
    }

    // Clamp to [1, 36] and round to 1 decimal
    handicap = Math.max(1.0, Math.min(36.0, handicap));
    handicap = Math.round(handicap * 10) / 10;

    players.push({
      id: `player-${i}`,
      name,
      handicap,
      quartile: 0, // Will be set during quartile calculation
    });
  }

  // Sort by handicap ascending
  players.sort((a, b) => a.handicap - b.handicap);

  // Assign quartiles
  const quartileSize = Math.ceil(players.length / 4);
  players.forEach((player, index) => {
    player.quartile = Math.floor(index / quartileSize) + 1;
  });

  return players;
}

// Quartile-based flight generation (packed to 4s)
function quartileDealAndPack(players: Player[]): Flight[] {
  if (players.length === 0) return [];

  // Re-sort and re-assign quartiles for the remaining players
  const sorted = [...players].sort((a, b) => a.handicap - b.handicap);
  const quartileSize = Math.ceil(sorted.length / 4);
  sorted.forEach((player, index) => {
    player.quartile = Math.floor(index / quartileSize) + 1;
  });

  // Split into quartiles
  const quartiles: Player[][] = [[], [], [], []];
  sorted.forEach((player) => {
    quartiles[player.quartile - 1].push(player);
  });

  const flights: Flight[] = [];
  const maxFlightSize = 4;
  let flightIndex = 0;
  let quartileIndices = [0, 0, 0, 0];

  // Pack flights to 4s: fill each flight fully before creating next
  while (true) {
    const flight: Flight = {
      id: `flight-auto-${flightIndex}`,
      index: flightIndex,
      players: [],
      isManual: false,
    };

    // Add one from each quartile if available, until flight is full
    let addedAny = false;
    while (flight.players.length < maxFlightSize) {
      let addedThisRound = false;
      for (let q = 0; q < 4; q++) {
        if (quartileIndices[q] < quartiles[q].length && flight.players.length < maxFlightSize) {
          flight.players.push(quartiles[q][quartileIndices[q]]);
          quartileIndices[q]++;
          addedAny = true;
          addedThisRound = true;
        }
      }
      if (!addedThisRound) break; // No more players available
    }

    if (flight.players.length > 0) {
      flights.push(flight);
      flightIndex++;
    }

    // Check if all distributed
    if (!addedAny || quartileIndices.every((idx, q) => idx >= quartiles[q].length)) {
      break;
    }
  }

  return flights;
}

function generateFlights(players: Player[], seed: number): Flight[] {
  const flights = quartileDealAndPack(players);

  // Force ugly edge case: ensure final flight has 2-3 players OR multiple from same quartile
  const lastFlight = flights[flights.length - 1];
  if (lastFlight && lastFlight.players.length >= 4) {
    // Move one player from last flight to second-to-last if possible
    if (flights.length >= 2) {
      const secondLast = flights[flights.length - 2];
      if (secondLast.players.length < 4) {
        const moved = lastFlight.players.pop()!;
        secondLast.players.push(moved);
      }
    }
  }

  // Also ensure at least one flight has 2+ players from same quartile
  let hasSameQuartile = false;
  for (const flight of flights) {
    const quartileCounts: Record<number, number> = {};
    flight.players.forEach((p) => {
      quartileCounts[p.quartile] = (quartileCounts[p.quartile] || 0) + 1;
    });
    if (Object.values(quartileCounts).some((count) => count >= 2)) {
      hasSameQuartile = true;
      break;
    }
  }

  if (!hasSameQuartile && flights.length >= 2) {
    // Swap two players from different flights to create same-quartile situation
    const flight1 = flights[0];
    const flight2 = flights[1];
    if (flight1.players.length > 0 && flight2.players.length > 0) {
      const p1 = flight1.players[0];
      const sameQuartilePlayer = flight2.players.find((p) => p.quartile === p1.quartile);
      if (sameQuartilePlayer && flight1.players.length < 4) {
        const index = flight2.players.indexOf(sameQuartilePlayer);
        flight2.players.splice(index, 1);
        flight1.players.push(sameQuartilePlayer);
      }
    }
  }

  // Ensure all flights start as automated (not manual)
  // No pre-touch edits - start with 0 Edited flights
  flights.forEach((flight) => {
    flight.isManual = false;
  });

  return flights;
}

// Full remainder recompute: freeze manual flights, rebuild automated from remaining players
function recomputeFromRemainder(flights: Flight[], seededN: number, displacedPlayers: Player[] = []): Flight[] {
  // Pre-recompute validation: collect all player IDs
  const allPlayerIdsBefore = new Set<string>();
  flights.forEach((flight) => {
    flight.players.forEach((p) => {
      if (allPlayerIdsBefore.has(p.id)) {
        console.error(`[Sandbox] Pre-recompute: Duplicate player ID ${p.id}`);
      }
      allPlayerIdsBefore.add(p.id);
    });
  });
  const totalBefore = allPlayerIdsBefore.size;
  if (totalBefore !== seededN) {
    console.error(`[Sandbox] Pre-recompute player count mismatch: ${totalBefore} !== ${seededN}`, {
      stage: "pre-recompute",
      expected: seededN,
      actual: totalBefore,
      inFlights: flights.reduce((sum, f) => sum + f.players.length, 0),
      allIds: Array.from(allPlayerIdsBefore).sort(),
    });
  }

  // Identify manual flights and collect their player IDs
  const manualFlights: Flight[] = [];
  const manualPlayerIds = new Set<string>();
  
  flights.forEach((flight) => {
    if (flight.isManual) {
      manualFlights.push(flight);
      flight.players.forEach((p) => manualPlayerIds.add(p.id));
    }
  });

  // Collect all remaining players (not in manual flights) + displaced players
  const remainingPlayers: Player[] = [...displacedPlayers];
  flights.forEach((flight) => {
    if (!flight.isManual) {
      flight.players.forEach((player) => {
        if (!manualPlayerIds.has(player.id)) {
          remainingPlayers.push(player);
        }
      });
    }
  });

  // Validate remaining players
  const remainingIds = new Set(remainingPlayers.map((p) => p.id));
  if (remainingIds.size !== remainingPlayers.length) {
    console.error(`[Sandbox] Duplicate players in remaining pool`);
  }
  const expectedRemaining = seededN - manualPlayerIds.size;
  if (remainingPlayers.length !== expectedRemaining) {
    console.error(`[Sandbox] Remaining players count mismatch: ${remainingPlayers.length} !== ${expectedRemaining}`, {
      stage: "remaining-pool",
      expected: expectedRemaining,
      actual: remainingPlayers.length,
      manualCount: manualPlayerIds.size,
    });
  }

  // Rebuild automated flights from remaining players
  // IMPORTANT: quartileDealAndPack creates flights with isManual = false (never sets isManual = true)
  const newAutoFlights = quartileDealAndPack(remainingPlayers);

  // Stitch: preserve manual flights in place, replace auto flight slots
  const result: Flight[] = [];
  let autoFlightIndex = 0;
  let globalIndex = 0;

  // First pass: preserve manual flights in their positions
  flights.forEach((flight) => {
    if (flight.isManual) {
      result.push({
        ...flight,
        index: globalIndex++,
      });
    } else {
      // This is an auto flight slot - replace with rebuilt auto flight if available
      if (autoFlightIndex < newAutoFlights.length) {
        // Preserve the original flight's ID to avoid duplicate keys
        result.push({
          ...newAutoFlights[autoFlightIndex],
          id: flight.id, // Preserve original ID
          index: globalIndex++,
        });
        autoFlightIndex++;
      }
      // If no more auto flights, skip this slot (will be removed)
    }
  });

  // Append any additional auto flights if we have more than original auto slots
  // Generate unique IDs for new flights
  let newFlightIdCounter = 0;
  while (autoFlightIndex < newAutoFlights.length) {
    // Generate a unique ID that doesn't conflict with existing flights
    let newId = `flight-auto-${Date.now()}-${newFlightIdCounter++}`;
    // Ensure it's unique by checking against existing IDs
    while (flights.some((f) => f.id === newId) || result.some((f) => f.id === newId)) {
      newId = `flight-auto-${Date.now()}-${newFlightIdCounter++}`;
    }
    result.push({
      ...newAutoFlights[autoFlightIndex],
      id: newId,
      index: globalIndex++,
    });
    autoFlightIndex++;
  }

  // Dev-only guard: verify recomputeFromRemainder never sets isManual on new flights
  const manualFlightsBefore = flights.filter((f) => f.isManual).length;
  const manualFlightsAfter = result.filter((f) => f.isManual).length;
  if (manualFlightsAfter > manualFlightsBefore) {
    console.warn(`[Sandbox] recomputeFromRemainder created manual flights! Before: ${manualFlightsBefore}, After: ${manualFlightsAfter}`);
  }

  // Post-recompute validation
  const allPlayerIdsAfter = new Set<string>();
  result.forEach((flight) => {
    flight.players.forEach((p) => {
      if (allPlayerIdsAfter.has(p.id)) {
        console.error(`[Sandbox] Post-recompute: Duplicate player ID ${p.id}`);
      }
      allPlayerIdsAfter.add(p.id);
    });
  });
  const totalAfter = allPlayerIdsAfter.size;
  if (totalAfter !== seededN) {
    console.error(`[Sandbox] Post-recompute player count mismatch: ${totalAfter} !== ${seededN}`, {
      stage: "post-recompute",
      expected: seededN,
      actual: totalAfter,
      inFlights: result.reduce((sum, f) => sum + f.players.length, 0),
      allIds: Array.from(allPlayerIdsAfter).sort(),
      missingIds: Array.from(allPlayerIdsBefore).filter((id) => !allPlayerIdsAfter.has(id)),
      extraIds: Array.from(allPlayerIdsAfter).filter((id) => !allPlayerIdsBefore.has(id)),
    });
  }

  // Check automated partial flights: should be at most one at the end
  const autoFlights = result.filter((f) => !f.isManual);
  const partialAutoFlights = autoFlights.filter((f) => f.players.length < 4);
  if (partialAutoFlights.length > 1) {
    console.warn(`[Sandbox] Multiple partial automated flights: ${partialAutoFlights.length}`);
  }

  return result;
}

export default function FlightsSandboxPage() {
  const router = useRouter();
  const [seed, setSeed] = useState<number>(() => {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem("DFI_SANDBOX_SEED");
      if (stored) return parseInt(stored, 10);
    }
    return Date.now();
  });
  const [playerCount, setPlayerCount] = useState<number>(0);
  const [flights, setFlights] = useState<Flight[]>([]);
  const [dragging, setDragging] = useState(false);
  const [displacedPlayerName, setDisplacedPlayerName] = useState<string | null>(null);
  const [draggedPlayerId, setDraggedPlayerId] = useState<string | null>(null);
  const [dragSource, setDragSource] = useState<{ flightId: string; playerIndex: number } | null>(null);
  const [pointerDragState, setPointerDragState] = useState<{
    playerId: string;
    flightId: string;
    startX: number;
    startY: number;
    currentX: number;
    currentY: number;
  } | null>(null);
  const [pointerOverTarget, setPointerOverTarget] = useState<string | null>(null);
  const dragStartTimeRef = useRef<number>(0);
  const dragThreshold = 10; // pixels
  const longPressThreshold = 200; // ms
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [showExportMessage, setShowExportMessage] = useState(false);
  const [isRecomputing, setIsRecomputing] = useState(false);
  const isFirstRender = useRef(true);

  // Initialize sandbox
  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("DFI_SANDBOX_SEED", String(seed));
    }

    // Reset first-render flag on seed change (reload)
    isFirstRender.current = true;

    const rng = new PRNG(seed);
    const count = rng.nextInt(50, 70);
    setPlayerCount(count);

    const players = generatePlayers(seed, count);
    const initialFlights = generateFlights(players, seed);
    setFlights(initialFlights);
  }, [seed]);

  const handleReload = useCallback(() => {
    // Generate new seed and reload
    const newSeed = Date.now();
    setSeed(newSeed);
  }, []);

  // Place handler removed - no longer needed with displacement model

  // Drop handler - must be defined before pointer handlers
  const handleDrop = useCallback(
    (targetPlayerId: string, targetFlightId: string) => {
      // Validate drop target first (before any mutations)
      const targetFlight = flights.find((f) => f.id === targetFlightId);
      if (!targetFlight) {
        // Invalid target - cancel drag, no mutations
        setDragging(false);
        setDraggedPlayerId(null);
        setDragSource(null);
        return;
      }

      const targetPlayerIndex = targetFlight.players.findIndex((p) => p.id === targetPlayerId);
      if (targetPlayerIndex === -1) {
        // Invalid target - cancel drag, no mutations
        setDragging(false);
        setDraggedPlayerId(null);
        setDragSource(null);
        return;
      }

      // Validate drag source
      if (!draggedPlayerId || !dragSource) {
        // Invalid state - cancel drag, no mutations
        setDragging(false);
        setDraggedPlayerId(null);
        setDragSource(null);
        return;
      }

      // Now we have a valid drop target - proceed with mutations
      const newFlights = flights.map((f) => ({
        ...f,
        players: [...f.players],
      }));

      // Find source flight and validate
      const sourceFlight = newFlights.find((f) => f.id === dragSource.flightId);
      if (!sourceFlight) {
        // Invalid source - cancel drag, no mutations
        setDragging(false);
        setDraggedPlayerId(null);
        setDragSource(null);
        return;
      }

      // Validate source player still exists at expected index
      if (sourceFlight.players[dragSource.playerIndex]?.id !== draggedPlayerId) {
        // Source changed - cancel drag, no mutations
        setDragging(false);
        setDraggedPlayerId(null);
        setDragSource(null);
        return;
      }

      // All validations passed - perform displacement swap
      const draggedPlayer = sourceFlight.players[dragSource.playerIndex];
      const updatedTargetFlight = newFlights.find((f) => f.id === targetFlightId)!;
      
      // Get the displaced player (B) before any mutations
      const displacedPlayer = updatedTargetFlight.players[targetPlayerIndex];
      
      // Remove dragged player (A) from source (only after confirming valid drop)
      sourceFlight.players.splice(dragSource.playerIndex, 1);
      // Source flight does NOT become manual

      // Remove displaced player (B) from destination first
      updatedTargetFlight.players.splice(targetPlayerIndex, 1);
      
      // Insert dragged player (A) at the same index in destination
      updatedTargetFlight.players.splice(targetPlayerIndex, 0, draggedPlayer);
      
      // Only destination flight becomes manual
      updatedTargetFlight.isManual = true;
      
      // Show transient message for displaced player
      setDisplacedPlayerName(displacedPlayer.name);
      setTimeout(() => setDisplacedPlayerName(null), 2000);
      
      // Immediately recompute automated flights from remainder (includes displaced B)
      setIsRecomputing(true);
      const recomputed = recomputeFromRemainder(newFlights, playerCount, [displacedPlayer]);
      setFlights(recomputed);
      setIsRecomputing(false);
      setDragging(false);
      setDraggedPlayerId(null);
      setDragSource(null);
    },
    [draggedPlayerId, dragSource, flights, playerCount]
  );

  // Pointer-based drag handlers (mobile-compatible)
  const handlePointerDown = useCallback((e: React.PointerEvent, playerId: string, flightId: string) => {
    // Only handle primary pointer (left mouse button or touch)
    if (e.button !== undefined && e.button !== 0) return;
    
    e.preventDefault();
    e.stopPropagation();
    
    const sourceFlight = flights.find((f) => f.id === flightId);
    if (!sourceFlight) return;
    
    const playerIndex = sourceFlight.players.findIndex((p) => p.id === playerId);
    if (playerIndex === -1) return;

    // Set pointer capture for this element
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    
    dragStartTimeRef.current = Date.now();
    setPointerDragState({
      playerId,
      flightId,
      startX: e.clientX,
      startY: e.clientY,
      currentX: e.clientX,
      currentY: e.clientY,
    });
  }, [flights]);

  const handlePointerMove = useCallback((e: React.PointerEvent) => {
    if (!pointerDragState) return;
    
    e.preventDefault();
    
    const dx = e.clientX - pointerDragState.startX;
    const dy = e.clientY - pointerDragState.startY;
    const distance = Math.sqrt(dx * dx + dy * dy);
    
    // Update current position
    setPointerDragState((prev) => prev ? {
      ...prev,
      currentX: e.clientX,
      currentY: e.clientY,
    } : null);
    
    // Only start dragging after threshold (prevents accidental drags during scroll)
    if (distance < dragThreshold) return;
    
    // Check if enough time has passed (long press threshold)
    const timeElapsed = Date.now() - dragStartTimeRef.current;
    if (timeElapsed < longPressThreshold) return;
    
    // Start visual drag feedback
    if (!dragging) {
      setDragging(true);
      setDraggedPlayerId(pointerDragState.playerId);
      const sourceFlight = flights.find((f) => f.id === pointerDragState.flightId);
      if (sourceFlight) {
        const playerIndex = sourceFlight.players.findIndex((p) => p.id === pointerDragState.playerId);
        if (playerIndex !== -1) {
          setDragSource({ flightId: pointerDragState.flightId, playerIndex });
        }
      }
    }
    
    // Find drop target via hit testing
    const elementBelow = document.elementFromPoint(e.clientX, e.clientY);
    if (elementBelow) {
      const targetKey = elementBelow.getAttribute('data-drop-target');
      if (targetKey && targetKey !== `${pointerDragState.flightId}-${pointerDragState.playerId}`) {
        setPointerOverTarget(targetKey);
      } else {
        setPointerOverTarget(null);
      }
    } else {
      setPointerOverTarget(null);
    }
  }, [pointerDragState, dragging, flights]);

  const handlePointerUp = useCallback((e: React.PointerEvent) => {
    if (!pointerDragState) return;
    
    e.preventDefault();
    (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
    
    // If we have a valid drop target, perform the swap
    if (pointerOverTarget && dragging && dragSource) {
      const [targetFlightId, targetPlayerId] = pointerOverTarget.split('-');
      if (targetFlightId && targetPlayerId) {
        handleDrop(targetPlayerId, targetFlightId);
      }
    }
    
    // Clear all drag state
    setPointerDragState(null);
    setPointerOverTarget(null);
    setDragging(false);
    setDraggedPlayerId(null);
    setDragSource(null);
  }, [pointerDragState, pointerOverTarget, dragging, dragSource, handleDrop]);

  const handlePointerCancel = useCallback((e: React.PointerEvent) => {
    e.preventDefault();
    (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
    
    // Cancel drag - no mutations
    setPointerDragState(null);
    setPointerOverTarget(null);
    setDragging(false);
    setDraggedPlayerId(null);
    setDragSource(null);
  }, []);

  // Legacy HTML5 drag handlers (for desktop fallback)
  const handleDragStart = useCallback((playerId: string, flightId: string) => {
    // Find source flight and index (for validation, not mutation)
    const sourceFlight = flights.find((f) => f.id === flightId);
    if (!sourceFlight) return;
    
    const playerIndex = sourceFlight.players.findIndex((p) => p.id === playerId);
    if (playerIndex === -1) return;

    // Store drag state (NO mutations yet)
    setDragging(true);
    setDraggedPlayerId(playerId);
    setDragSource({ flightId, playerIndex });
  }, [flights]);

  const handleDragEnd = useCallback(() => {
    // On drag end without valid drop: clear state, NO mutations
    // Player remains in their original flight
    setDragging(false);
    setDraggedPlayerId(null);
    setDragSource(null);
  }, []);

  const handleReset = useCallback(() => {
    // Regenerate flights (clears all manual flags)
    const players = generatePlayers(seed, playerCount);
    const resetFlights = generateFlights(players, seed);
    setFlights(resetFlights);
    setShowResetConfirm(false);
  }, [seed, playerCount]);

  const handleBack = useCallback(() => {
    router.back();
  }, [router]);

  const canReset = !dragging && !isRecomputing;

  // Calculate handicap range and edited flights count
  const handicapRange = useMemo(() => {
    if (flights.length === 0) return { min: 0, max: 0 };
    const allHandicaps = flights.flatMap((f) => f.players.map((p) => p.handicap));
    if (allHandicaps.length === 0) return { min: 0, max: 0 };
    return {
      min: Math.min(...allHandicaps),
      max: Math.max(...allHandicaps),
    };
  }, [flights]);

  const editedFlightsCount = useMemo(() => {
    return flights.filter((f) => f.isManual).length;
  }, [flights]);

  // Player count invariant check (dev-only)
  const playerCountStatus = useMemo(() => {
    const totalInFlights = flights.reduce((sum, f) => sum + f.players.length, 0);
    const missing = playerCount - totalInFlights;
    
    return {
      inFlights: totalInFlights,
      total: totalInFlights,
      expected: playerCount,
      missing,
      isValid: missing === 0,
    };
  }, [flights, playerCount]);

  // Invariant assertion after every state change
  useEffect(() => {
    if (playerCountStatus.missing !== 0) {
      console.error(`[Sandbox] Player count mismatch!`, {
        expected: playerCountStatus.expected,
        inFlights: playerCountStatus.inFlights,
        total: playerCountStatus.total,
        missing: playerCountStatus.missing,
      });
      
      // Dump all player IDs to find missing ones
      const allPlayerIds = new Set<string>();
      flights.forEach((flight) => {
        flight.players.forEach((p) => allPlayerIds.add(p.id));
      });
      console.error(`[Sandbox] Current player IDs:`, Array.from(allPlayerIds).sort());
      
      // Check for duplicates
      const idCounts: Record<string, number> = {};
      flights.forEach((flight) => {
        flight.players.forEach((p) => {
          idCounts[p.id] = (idCounts[p.id] || 0) + 1;
        });
      });
      const duplicates = Object.entries(idCounts).filter(([_, count]) => count > 1);
      if (duplicates.length > 0) {
        console.error(`[Sandbox] Duplicate player IDs:`, duplicates);
      }
    }
  }, [playerCountStatus, flights]);

  // First-render check: should start with 0 edited flights on initial load
  useEffect(() => {
    if (isFirstRender.current && flights.length > 0) {
      const manualFlights = flights.filter((f) => f.isManual);
      if (manualFlights.length !== 0) {
        console.warn(`[Sandbox] Expected 0 edited flights on initial load, found ${manualFlights.length}`, {
          manualFlightIds: manualFlights.map((f) => f.id),
          allFlightIds: flights.map((f) => ({ id: f.id, isManual: f.isManual })),
        });
      }
      isFirstRender.current = false;
    }
  }, [flights]);

  const [showDiagnostics, setShowDiagnostics] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      {/* Compact sticky top bar */}
      <div className="sticky top-0 z-20 border-b border-border bg-surface">
        <div className="flex items-center justify-between px-4 h-14">
          <button
            onClick={handleBack}
            className="text-sm text-secondary hover:text-foreground"
          >
            ← Back
          </button>
          <h1 className="text-base font-semibold text-foreground">Sandbox · Flights</h1>
          <button
            onClick={handleReload}
            className="text-sm text-secondary hover:text-foreground font-medium"
          >
            Reload
          </button>
        </div>
      </div>

      {/* Collapsible diagnostics strip */}
      <div className="sticky top-14 z-10 border-b border-border bg-surface">
        <div className="px-4 py-2">
          {!showDiagnostics ? (
            <div className="flex items-center justify-between">
              <div className="text-xs text-secondary whitespace-nowrap overflow-hidden text-ellipsis">
                Players {playerCount} · Edited {editedFlightsCount}
              </div>
              <button
                onClick={() => setShowDiagnostics(true)}
                className="text-xs text-secondary hover:text-foreground font-medium ml-2 flex-shrink-0"
              >
                Details
              </button>
            </div>
          ) : (
            <div className="space-y-1">
              <div className="text-xs text-secondary">
                Players: {playerCount}
              </div>
              <div className="text-xs text-secondary">
                Hcp: {handicapRange.min.toFixed(1)}–{handicapRange.max.toFixed(1)}
              </div>
              <div className="text-xs text-secondary">
                Edited flights: {editedFlightsCount}
              </div>
              <div className="text-xs text-secondary">
                In flights: {playerCountStatus.inFlights}/{playerCountStatus.expected}
              </div>
              {playerCountStatus.missing !== 0 && (
                <div 
                  className="text-xs font-semibold"
                  style={{ color: "var(--color-danger)" }}
                >
                  Missing: {playerCountStatus.missing}
                </div>
              )}
              <button
                onClick={() => setShowDiagnostics(false)}
                className="text-xs text-secondary hover:text-foreground font-medium mt-1"
              >
                Hide details
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Transient displacement message */}
      {displacedPlayerName && (
        <div 
          className="sticky z-10 border-b border-border bg-surface/95 px-4 py-2"
          style={{ top: showDiagnostics ? '200px' : '96px' }}
        >
          <div className="text-xs text-secondary text-center">
            {displacedPlayerName} moved back into the pool
          </div>
        </div>
      )}

      {/* Flights list */}
      <div className="px-4 pt-4 pb-24 space-y-4">
        {flights.map((flight) => (
          <div
            key={flight.id}
            className={`rounded-lg border p-4 ${
              flight.isManual
                ? "border-foreground/30 bg-foreground/2"
                : "border-border bg-surface"
            }`}
          >
            <div className="mb-3">
              <h2 className="text-sm font-semibold text-foreground">
                Flight {flight.index + 1}
                {flight.isManual && (
                  <span className="ml-2 text-xs font-normal text-secondary">· Edited</span>
                )}
              </h2>
            </div>
            <div className="space-y-2">
              {flight.players.map((player) => {
                const dropTargetKey = `${flight.id}-${player.id}`;
                const isDragging = draggedPlayerId === player.id;
                const isOverTarget = pointerOverTarget === dropTargetKey;
                
                return (
                  <div
                    key={player.id}
                    data-drop-target={dropTargetKey}
                    draggable
                    onPointerDown={(e) => handlePointerDown(e, player.id, flight.id)}
                    onPointerMove={handlePointerMove}
                    onPointerUp={handlePointerUp}
                    onPointerCancel={handlePointerCancel}
                    onDragStart={(e) => {
                      handleDragStart(player.id, flight.id);
                      e.dataTransfer.effectAllowed = "move";
                    }}
                    onDragEnd={(e) => {
                      handleDragEnd();
                      // Remove any leftover highlight classes
                      document.querySelectorAll(".drag-over").forEach((el) => {
                        el.classList.remove("drag-over");
                      });
                    }}
                    onDragOver={(e) => {
                      e.preventDefault();
                      e.dataTransfer.dropEffect = "move";
                      e.currentTarget.classList.add("drag-over", "bg-background/50");
                    }}
                    onDragLeave={(e) => {
                      e.currentTarget.classList.remove("drag-over", "bg-background/50");
                    }}
                    onDrop={(e) => {
                      e.preventDefault();
                      e.currentTarget.classList.remove("drag-over", "bg-background/50");
                      handleDrop(player.id, flight.id);
                    }}
                    style={{
                      touchAction: pointerDragState?.playerId === player.id ? 'none' : 'auto',
                      transform: isDragging ? 'scale(0.95)' : undefined,
                    }}
                    className={`flex items-center gap-3 rounded-md border border-border bg-background px-3 py-2 cursor-move transition-all ${
                      isDragging ? "opacity-50" : isOverTarget ? "bg-background/50 ring-2 ring-foreground/30" : "hover:bg-background/30"
                    }`}
                  >
                    <span className="text-secondary text-xs select-none">≡</span>
                    <div className="flex-1">
                      <div className="text-sm font-medium text-foreground">{player.name}</div>
                      <div className="text-xs text-secondary">HCP {player.handicap}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Reset section - inline confirmation */}
      <div className="px-5 py-4 border-t border-border">
        {showResetConfirm ? (
          <div className="space-y-3">
            <div>
              <h3 className="text-sm font-semibold text-foreground mb-1">
                Reset all flights to automatic quartiles?
              </h3>
              <p className="text-xs text-secondary">
                This will remove all manual edits. You can rearrange again afterwards.
              </p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={handleReset}
                className="rounded-md border border-border bg-surface px-3 py-1.5 text-xs font-medium text-foreground hover:bg-background"
              >
                Reset flights
              </button>
              <button
                onClick={() => setShowResetConfirm(false)}
                className="rounded-md border border-border bg-surface px-3 py-1.5 text-xs font-medium text-secondary hover:bg-background"
              >
                Cancel
              </button>
            </div>
          </div>
        ) : (
          <button
            onClick={() => setShowResetConfirm(true)}
            disabled={!canReset}
            className={`text-xs font-medium underline ${
              canReset
                ? "text-secondary hover:text-foreground"
                : "text-secondary/50 cursor-not-allowed no-underline"
            }`}
          >
            Reset to quartiles
          </button>
        )}
      </div>

      {/* Export button */}
      <div className="sticky bottom-0 border-t border-border bg-surface px-5 py-4">
        {(isRecomputing || playerCountStatus.missing !== 0) && (
          <div className="text-xs text-secondary mb-2 text-center">
            {isRecomputing
              ? "Updating flights…"
              : playerCountStatus.missing !== 0
              ? "Player count mismatch detected"
              : ""}
          </div>
        )}
        <button
          onClick={() => setShowExportMessage(true)}
          disabled={isRecomputing || playerCountStatus.missing !== 0}
          className="w-full rounded-lg btn-primary px-4 py-3 text-sm font-medium text-white hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Export details
        </button>
      </div>

      {/* Export message */}
      {showExportMessage && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-foreground/50 p-4">
          <div className="w-full max-w-md rounded-t-xl border-t border-border bg-surface p-6">
            <h3 className="text-sm font-semibold text-foreground mb-2">
              Sandbox: export is disabled.
            </h3>
            <p className="text-xs text-secondary mb-4">
              This is a development sandbox. Export functionality is not available here.
            </p>
            <button
              onClick={() => setShowExportMessage(false)}
              className="w-full rounded-md border border-border bg-surface px-4 py-2 text-sm font-medium text-foreground hover:bg-background"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Test checklist */}
      <div className="px-5 py-6 border-t border-border">
        <h3 className="text-xs font-semibold text-foreground mb-3 uppercase tracking-wide">
          Sandbox checklist
        </h3>
        <ul className="space-y-1.5 text-xs text-secondary">
          <li>• Can you find the carried person at all times?</li>
          <li>• Can you complete a swap chain A→B→C easily?</li>
          <li>• Does Place always resolve the layout?</li>
          <li>• Is Reset hard to trigger accidentally?</li>
          <li>• Do incomplete flights feel normal (not error)?</li>
          <li>• Does Back auto-place if someone is in hand?</li>
        </ul>
      </div>
    </div>
  );
}
