/**
 * Trip Readiness Helpers
 * 
 * Helper functions for computing trip readiness, especially for scenarios
 * with detailed readiness gates (e.g., cross_border_agent).
 */

import { type Trip, type Attendee } from "./tripActions";
import { type ScenarioKey, type ScenarioDefinition, getScenario } from "./scenarios/registry";
import { type TripRecipe } from "./tripIntent";
import { createSupabaseBrowserClient } from "./supabaseBrowser";

/**
 * Passport profile data structure
 */
export type PassportProfile = {
  passport_full_name: string | null;
  passport_number: string | null;
  passport_nationality: string | null;
  passport_date_of_birth: string | null;
  passport_expiry_date: string | null;
};

/**
 * Check if a member is export-ready for agent roster
 * 
 * An attendee is export-ready if:
 * - RSVP status === 'confirmed' (yes)
 * - handicap is present
 * - ALL passport fields are present and non-empty
 */
export function isMemberAgentReady(
  attendee: Attendee,
  profile: PassportProfile | null
): { isReady: boolean; missingFields: Array<"passport_full_name" | "passport_number" | "passport_nationality" | "passport_date_of_birth" | "passport_expiry_date" | "handicap"> } {
  const missingFields: Array<"passport_full_name" | "passport_number" | "passport_nationality" | "passport_date_of_birth" | "passport_expiry_date" | "handicap"> = [];

  // Check RSVP status
  if (attendee.status !== "confirmed") {
    // Not confirmed, so not ready (but we don't track this in missingFields)
    return { isReady: false, missingFields: [] };
  }

  // Check handicap
  if (attendee.handicapForTrip === null || attendee.handicapForTrip === undefined) {
    missingFields.push("handicap");
  }

  // Check passport fields
  if (!profile) {
    // No profile at all - all passport fields are missing
    missingFields.push("passport_full_name", "passport_number", "passport_nationality", "passport_date_of_birth", "passport_expiry_date");
  } else {
    // Check each passport field
    if (!profile.passport_full_name || profile.passport_full_name.trim().length === 0) {
      missingFields.push("passport_full_name");
    }
    if (!profile.passport_number || profile.passport_number.trim().length === 0) {
      missingFields.push("passport_number");
    }
    if (!profile.passport_nationality || profile.passport_nationality.trim().length === 0) {
      missingFields.push("passport_nationality");
    }
    if (!profile.passport_date_of_birth || profile.passport_date_of_birth.trim().length === 0) {
      missingFields.push("passport_date_of_birth");
    }
    if (!profile.passport_expiry_date || profile.passport_expiry_date.trim().length === 0) {
      missingFields.push("passport_expiry_date");
    }
  }

  return {
    isReady: missingFields.length === 0,
    missingFields,
  };
}

/**
 * Get agent roster status for a trip
 * 
 * Aggregates readiness across all attendees to determine:
 * - Total yes count (confirmed attendees)
 * - Export-ready count (confirmed + all fields complete)
 * - Not-ready members with their missing fields
 */
export async function getAgentRosterStatus(
  trip: Trip
): Promise<{
  yesCount: number;
  exportReadyCount: number;
  notReadyMembers: Array<{
    memberId: string;
    memberName: string;
    missingFields: Array<"passport_full_name" | "passport_number" | "passport_nationality" | "passport_date_of_birth" | "passport_expiry_date" | "handicap">;
  }>;
}> {
  // Get confirmed attendees
  const confirmedAttendees = (trip.attendees || []).filter((a) => a.status === "confirmed");
  const yesCount = confirmedAttendees.length;

  if (yesCount === 0) {
    return {
      yesCount: 0,
      exportReadyCount: 0,
      notReadyMembers: [],
    };
  }

  // Fetch passport data for all confirmed attendees
  const memberIds = confirmedAttendees
    .map((a) => a.memberId)
    .filter((id): id is string => !!id);

  const passportData = await fetchPassportData(memberIds);

  // Check each attendee
  let exportReadyCount = 0;
  const notReadyMembers: Array<{
    memberId: string;
    memberName: string;
    missingFields: Array<"passport_full_name" | "passport_number" | "passport_nationality" | "passport_date_of_birth" | "passport_expiry_date" | "handicap">;
  }> = [];

  for (const attendee of confirmedAttendees) {
    if (!attendee.memberId) {
      // Attendee without memberId cannot be export-ready
      notReadyMembers.push({
        memberId: "",
        memberName: attendee.name,
        missingFields: ["passport_full_name", "passport_number", "passport_nationality", "passport_date_of_birth", "passport_expiry_date", "handicap"],
      });
      continue;
    }

    const profile = passportData[attendee.memberId] || null;
    const readiness = isMemberAgentReady(attendee, profile);

    if (readiness.isReady) {
      exportReadyCount++;
    } else {
      notReadyMembers.push({
        memberId: attendee.memberId,
        memberName: attendee.name,
        missingFields: readiness.missingFields,
      });
    }
  }

  return {
    yesCount,
    exportReadyCount,
    notReadyMembers,
  };
}

/**
 * Fetch passport data for a list of member IDs from member_profiles
 * Returns a map of memberId -> passport data
 */
async function fetchPassportData(memberIds: string[]): Promise<Record<string, PassportProfile>> {
  if (memberIds.length === 0) return {};

  const supabase = createSupabaseBrowserClient();
  const { data: profiles, error } = await supabase
    .from("member_profiles")
    .select("member_id,passport_full_name,passport_number,passport_nationality,passport_date_of_birth,passport_expiry_date")
    .in("member_id", memberIds);

  if (error) {
    console.warn("[tripReadiness] Failed to fetch passport data:", error);
    return {};
  }

  const result: Record<string, PassportProfile> = {};

  for (const p of profiles || []) {
    result[p.member_id] = {
      passport_full_name: p.passport_full_name,
      passport_number: p.passport_number,
      passport_nationality: p.passport_nationality,
      passport_date_of_birth: p.passport_date_of_birth,
      passport_expiry_date: p.passport_expiry_date,
    };
  }

  return result;
}

/**
 * Compute detailed readiness for cross_border_agent scenario
 * This requires fetching passport data from the server
 */
export async function computeBatamReadiness(
  trip: Trip,
  scenario: ScenarioDefinition
): Promise<{
  basics: { done: boolean; missing: Array<"trip_date" | "course_id"> };
  rosterPack: {
    readyCount: number;
    totalYesCount: number;
    ready: boolean; // true when exportReadyCount === yesCount && yesCount > 0
    missingReasonsBreakdown: Array<{
      memberId: string;
      memberName: string;
      missingFields: Array<"passport_full_name" | "passport_number" | "passport_nationality" | "passport_date_of_birth" | "passport_expiry_date" | "handicap">;
    }>;
  };
  agentItinerary: { done: boolean; missing: Array<"meeting_point" | "meet_time" | "ferry_details"> };
  nextAction: "set_basics" | "collect_roster" | "export_to_agent" | "enter_itinerary" | "done";
}> {
  // Check if scenario has requiredForAgentExport (cross_border_agent only)
  if (!scenario.requiredForAgentExport) {
    throw new Error("computeBatamReadiness called for scenario without requiredForAgentExport");
  }

  // Basics: trip_date + course_id (from requiredForReadiness.basics)
  const basicsRequired = scenario.requiredForReadiness.basics || [];
  const basicsMissing: Array<"trip_date" | "course_id"> = [];
  if (basicsRequired.includes("trip_date") && !trip.date) basicsMissing.push("trip_date");
  if (basicsRequired.includes("course_id") && !trip.courseId) basicsMissing.push("course_id");
  const basics = {
    done: basicsMissing.length === 0,
    missing: basicsMissing,
  };

  // Roster pack: RSVP yes + passport fields + handicap
  // Use the new helper function to compute roster status
  const rosterStatus = await getAgentRosterStatus(trip);
  
  // Roster is ready when all confirmed attendees are export-ready
  const rosterReady = rosterStatus.exportReadyCount === rosterStatus.yesCount && rosterStatus.yesCount > 0;
  
  const rosterPack = {
    readyCount: rosterStatus.exportReadyCount,
    totalYesCount: rosterStatus.yesCount,
    ready: rosterReady,
    missingReasonsBreakdown: rosterStatus.notReadyMembers,
  };

  // Agent itinerary: meeting_point + meet_time + ferry_details (from requiredForReadiness.itinerary)
  const itineraryRequired = scenario.requiredForReadiness.itinerary || [];
  const itineraryMissing: Array<"meeting_point" | "meet_time" | "ferry_details"> = [];
  for (const field of itineraryRequired) {
    if (field === "meeting_point" && (!trip.logistics?.meetingPoint || trip.logistics.meetingPoint.trim().length === 0)) {
      itineraryMissing.push("meeting_point");
    } else if (field === "meet_time" && (!trip.logistics?.meetTime || trip.logistics.meetTime.trim().length === 0)) {
      itineraryMissing.push("meet_time");
    } else if (field === "ferry_details" && (!trip.logistics?.ferryDetails || trip.logistics.ferryDetails.trim().length === 0)) {
      itineraryMissing.push("ferry_details");
    }
  }
  const agentItinerary = {
    done: itineraryMissing.length === 0,
    missing: itineraryMissing,
  };

  // Determine next action based on readiness gates
  let nextAction: "set_basics" | "collect_roster" | "export_to_agent" | "enter_itinerary" | "done" = "done";
  if (!basics.done) {
    nextAction = "set_basics";
  } else if (!rosterPack.ready) {
    // Roster not ready: either no confirmed attendees or some are missing fields
    nextAction = "collect_roster";
  } else if (rosterPack.ready && !agentItinerary.done) {
    // Roster is complete, but itinerary is not - ready to export to agent
    nextAction = "export_to_agent";
  } else if (agentItinerary.done) {
    nextAction = "done";
  } else {
    // Fallback: should enter itinerary
    nextAction = "enter_itinerary";
  }

  return {
    basics,
    rosterPack,
    agentItinerary,
    nextAction,
  };
}
