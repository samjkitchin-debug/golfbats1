/**
 * Trip Instrumentation
 * 
 * Minimal event logging for trip creation/setup flows.
 * Events are logged to console in dev mode.
 */

type TripEvent =
  | { type: "create_started"; tripId?: number; groupId: string }
  | { type: "create_completed"; tripId: number; groupId: string; scenarioKey?: string | null }
  | { type: "create_abandoned"; groupId: string; step: number }
  | { type: "scenario_selected"; scenarioKey: string; groupId: string; source: "fast_lane" | "describe" | "manual" }
  | { type: "manage_loaded"; tripId: number; phase: string; nextStep: string | null; scenarioKey?: string | null }
  | { type: "next_step_clicked"; tripId: number; step: string }
  | { type: "step_skipped"; tripId: number; step: string }
  | { type: "dead_end_detected"; tripId: number; phase: string; context: string };

/**
 * Emit a trip event (console.log in dev, could be extended to analytics)
 */
export function emitTripEvent(event: TripEvent) {
  if (typeof window === "undefined") return;
  
  if (process.env.NODE_ENV !== "production") {
    console.log("[Trip Event]", event);
  }
  
  // Future: send to analytics service
  // if (window.gtag) {
  //   window.gtag("event", event.type, { ...event });
  // }
}
