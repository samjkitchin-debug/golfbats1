/**
 * Trip Scenario System
 * 
 * Classifies common mates-golf outings with minimal prompts, then derives
 * a coordination sequence (setup steps) and readiness.
 * 
 * Scenario truth lives in src/app/lib/scenarios/registry.ts and docs/trips/scenarios.md
 * 
 * NOTE: Scenario definitions are in ./scenarios/registry.ts
 * NOTE: Classification logic is in ./scenarios/classifier.ts
 */

import { type TripRecipe } from "./tripIntent";
import { type Trip } from "./tripActions";
import { computeDefaultCutoffAt } from "./tripDates";
import { type ScenarioKey, getScenario, type TripSetupStep } from "./scenarios/registry";
import { deriveScenarioKey, type ScenarioAnswers } from "./scenarios/classifier";

// Re-export for backwards compatibility
export type { ScenarioKey, TripSetupStep } from "./scenarios/registry";
export type { ScenarioAnswers } from "./scenarios/classifier";
export { deriveScenarioKey } from "./scenarios/classifier";

/**
 * Trip readiness result
 * For scenarios with readinessGates (e.g., cross_border_agent), includes detailed breakdown
 */
export type TripReadiness = {
  missing: TripSetupStep[];
  nextStep: TripSetupStep | null;
  isReady: boolean;
  // Batam canonical readiness gates (for cross_border_agent)
  basics?: {
    done: boolean;
    missing: Array<"trip_date" | "course_id">;
  };
  rosterPack?: {
    readyCount: number;
    totalYesCount: number;
    ready: boolean; // true when exportReadyCount === yesCount && yesCount > 0
    missingReasonsBreakdown: Array<{
      memberId: string;
      memberName: string;
      missingFields: Array<"passport_full_name" | "passport_number" | "passport_nationality" | "passport_date_of_birth" | "passport_expiry_date" | "handicap">;
    }>;
  };
  agentItinerary?: {
    done: boolean;
    missing: Array<"meeting_point" | "meet_time" | "ferry_details">;
  };
  nextAction?: "set_basics" | "collect_roster" | "export_to_agent" | "enter_itinerary" | "done";
};

// deriveScenarioKey is now exported from ./scenarios/classifier.ts

/**
 * Derive TripRecipe from scenario key.
 * Reads from scenario registry - no per-scenario logic here.
 */
export function deriveTripRecipeFromScenario(
  scenarioKey: ScenarioKey,
  tripDate?: string
): TripRecipe {
  const scenario = getScenario(scenarioKey);
  // Return a deep copy to avoid mutations
  return JSON.parse(JSON.stringify(scenario.recipe)) as TripRecipe;
}

/**
 * Get trip readiness based on scenario requirements.
 * Reads from scenario registry - no per-scenario conditional logic.
 * Returns missing steps, next step, and readiness status.
 */
export function getTripReadiness(
  trip: Trip,
  recipe: TripRecipe,
  scenarioKey: ScenarioKey
): TripReadiness {
  const scenario = getScenario(scenarioKey);
  const missing: TripSetupStep[] = [];
  let nextStep: TripSetupStep | null = null;

  // Check each required step from the scenario definition (use steps array)
  for (const step of scenario.steps) {
    let isComplete = false;

    switch (step) {
      case "basics":
        isComplete = !!(trip.name && trip.date);
        break;

      case "course":
        isComplete = !!trip.courseId;
        break;

      case "signups":
        isComplete = !!(recipe.sections.signups && trip.cutoffAt);
        break;

      case "capacity":
        isComplete = !!(recipe.sections.capacity && trip.capacity && trip.capacity > 0);
        break;

      case "logistics":
        if (recipe.sections.logistics) {
          const hasMeetingPoint = !!(trip.logistics?.meetingPoint && trip.logistics.meetingPoint.trim().length > 0);
          const hasMeetTime = !!(trip.logistics?.meetTime && trip.logistics.meetTime.trim().length > 0);
          const hasFerryDetails = !!(trip.logistics?.ferryDetails && trip.logistics.ferryDetails.trim().length > 0);
          
          // Check if ferryDetails is required for this scenario (from requiredForReadiness.logistics)
          const logisticsRequired = scenario.requiredForReadiness.logistics || [];
          const requiresFerryDetails = logisticsRequired.includes("ferry_details");
          const ferryDetailsValid = requiresFerryDetails ? hasFerryDetails : true;
          
          isComplete = hasMeetingPoint && hasMeetTime && ferryDetailsValid;
        } else {
          // Logistics not required by recipe, so step is complete
          isComplete = true;
        }
        break;

      case "export":
        // Export is a soft requirement - readiness doesn't block on it
        // but we can track if it's ready (has attendees when export is enabled)
        if (recipe.sections.export) {
          isComplete = !!(trip.attendees && trip.attendees.length > 0);
        } else {
          // Export not required by recipe, so step is complete
          isComplete = true;
        }
        break;
    }

    if (!isComplete) {
      missing.push(step);
      if (!nextStep) {
        nextStep = step;
      }
    }
  }

  const isReady = missing.length === 0;

  return {
    missing,
    nextStep,
    isReady,
  };
}

/**
 * Get detailed trip readiness for scenarios with readinessGates (e.g., cross_border_agent).
 * This is an async function that fetches passport data from the server.
 * 
 * For scenarios without readinessGates, this function returns the basic readiness.
 */
export async function getTripReadinessDetailed(
  trip: Trip,
  recipe: TripRecipe,
  scenarioKey: ScenarioKey
): Promise<TripReadiness> {
  const scenario = getScenario(scenarioKey);
  
  // Get basic readiness first
  const basicReadiness = getTripReadiness(trip, recipe, scenarioKey);

  // If scenario has requiredForAgentExport (cross_border_agent only), compute detailed readiness
  if (scenario.requiredForAgentExport) {
    const { computeBatamReadiness } = await import("./tripReadiness");
    const detailed = await computeBatamReadiness(trip, scenario);
    
    return {
      ...basicReadiness,
      basics: detailed.basics,
      rosterPack: detailed.rosterPack,
      agentItinerary: detailed.agentItinerary,
      nextAction: detailed.nextAction,
    };
  }

  // No detailed readiness gates, return basic readiness
  return basicReadiness;
}
