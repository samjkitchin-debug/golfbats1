"use client";

import { useEffect, useState } from "react";
import { useRouter, useParams } from "next/navigation";
import { loadTrips, type Trip } from "../../../lib/tripActions";
import { loadCourses, type Course } from "../../../lib/courseActions";
import Link from "next/link";

export default function GameDayPage() {
  const router = useRouter();
  const params = useParams<{ roundId: string }>();
  const roundId = params.roundId ? parseInt(params.roundId, 10) : null;

  const [trip, setTrip] = useState<Trip | null>(null);
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeGroupId, setActiveGroupId] = useState<string | null>(null);

  useEffect(() => {
    document.title = "DayForeIt - GameDay";
  }, []);

  // Load bootstrap and trip data
  useEffect(() => {
    async function loadData() {
      try {
        const bootstrapRes = await fetch("/api/me/bootstrap", { credentials: "include" });
        if (!bootstrapRes.ok) {
          if (bootstrapRes.status === 401) {
            router.replace("/login");
            return;
          }
          throw new Error("Failed to load bootstrap data");
        }
        const bootstrap = await bootstrapRes.json();
        setActiveGroupId(bootstrap.activeGroupId);

        if (!roundId || !bootstrap.activeGroupId) {
          setLoading(false);
          return;
        }

        // Load trips and courses
        const [tripsData, coursesData] = await Promise.all([
          loadTrips(bootstrap.activeGroupId, false),
          loadCourses(),
        ]);

        const foundTrip = tripsData.find((t) => t.id === roundId);
        setTrip(foundTrip || null);
        setCourses(coursesData);
      } catch (error) {
        console.error("Failed to load data:", error);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, [roundId, router]);

  if (loading) {
    return (
      <div className="container mx-auto max-w-2xl px-4 py-8">
        <div className="rounded-xl border border-border bg-surface p-8 text-center">
          <p className="text-sm text-muted">Loading…</p>
        </div>
      </div>
    );
  }

  if (!trip) {
    return (
      <div className="container mx-auto max-w-2xl px-4 py-8">
        <div className="rounded-xl border border-border bg-surface p-8 text-center">
          <p className="text-sm text-muted">Round not found</p>
          <Link href="/" className="mt-4 inline-block text-sm text-brand-green hover:underline">
            Go home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto max-w-2xl px-4 py-8">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-foreground">GameDay</h1>
        <p className="mt-2 text-sm text-muted">Your round is live</p>
      </div>

      <div className="rounded-xl border border-border bg-surface p-6 space-y-4">
        <div>
          <div className="text-sm font-medium text-muted uppercase tracking-wide mb-2">Round</div>
          <div className="text-lg font-semibold text-foreground">{trip.name || "Round"}</div>
          <div className="text-sm text-muted mt-1">
            {new Date(trip.date + "T00:00:00").toLocaleDateString("en-GB", {
              weekday: "long",
              day: "numeric",
              month: "long",
            })}
          </div>
        </div>

        {!trip.courseId && (
          <div className="rounded-lg border border-border bg-muted/30 p-4">
            <div className="text-sm font-medium text-foreground mb-2">Select course</div>
            <p className="text-xs text-muted mb-3">Choose a course before scoring</p>
            <select
              className="w-full rounded-lg border border-border bg-surface px-4 py-2 text-sm text-foreground"
              onChange={async (e) => {
                // TODO: Update trip with selected course
                const courseId = e.target.value;
                if (courseId && activeGroupId) {
                  // For now, just show the selection
                  console.log("Course selected:", courseId);
                }
              }}
            >
              <option value="">Select a course</option>
              {courses.map((course) => (
                <option key={course.id} value={course.id}>
                  {course.name} {course.location ? `- ${course.location}` : ""}
                </option>
              ))}
            </select>
          </div>
        )}

        <div>
          <div className="text-sm font-medium text-muted uppercase tracking-wide mb-2">Players</div>
          <div className="text-sm text-foreground">
            {trip.attendees.length === 0 ? "No players yet" : `${trip.attendees.length} player${trip.attendees.length === 1 ? "" : "s"}`}
          </div>
        </div>

        <div className="pt-4 border-t border-border">
          <Link
            href={`/trips/${trip.id}`}
            className="block w-full rounded-lg border border-border bg-surface px-4 py-2 text-sm font-medium text-foreground hover:bg-muted/50 text-center"
          >
            Exit GameDay
          </Link>
        </div>
      </div>
    </div>
  );
}
