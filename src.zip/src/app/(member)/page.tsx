"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { createBrowserClient } from "@supabase/ssr";
import { loadTrips, joinTrip, leaveTrip, type Trip } from "../lib/tripActions";
import { loadCourses, type Course } from "../lib/courseActions";
import { getTripCourseText } from "../lib/tripDisplay";
import { ConfirmModal } from "../components/ConfirmModal";
import { PromptModal } from "../components/PromptModal";
import { TripCard } from "../components/TripCard";

export default function HomePage() {
  const [trips, setTrips] = useState<Trip[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [currentUserName, setCurrentUserName] = useState<string | null>(null);
  const [confirmModal, setConfirmModal] = useState<{ isOpen: boolean; title: string; message: string; onConfirm: () => void; onCancel: () => void }>({
    isOpen: false,
    title: "",
    message: "",
    onConfirm: () => {},
    onCancel: () => {},
  });
  const [promptModal, setPromptModal] = useState<{ isOpen: boolean; title: string; message: string; defaultValue: string; placeholder: string; onConfirm: (value: string) => void; onCancel: () => void }>({
    isOpen: false,
    title: "",
    message: "",
    defaultValue: "",
    placeholder: "",
    onConfirm: () => {},
    onCancel: () => {},
  });

  const supabase = useMemo(() => {
    return createBrowserClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
    );
  }, []);

  useEffect(() => {
    document.title = "GolfBats - Home";
  }, []);

  useEffect(() => {
    async function loadData() {
      let retries = 0;
      const maxRetries = 3;
      
      while (retries < maxRetries) {
        try {
          // Bypass cache on first load to ensure we get fresh data
          const [tripsData, coursesData] = await Promise.all([
            loadTrips(retries === 0), // Bypass cache on first attempt
            loadCourses()
          ]);
          
          if (tripsData.length === 0 && retries < maxRetries - 1) {
            // If we got empty data, retry with cache bypass
            retries++;
            await new Promise(resolve => setTimeout(resolve, 500)); // Wait 500ms before retry
            continue;
          }
          
          setTrips(tripsData);
          setCourses(coursesData);
          return; // Success, exit retry loop
        } catch (error) {
          console.error(`Failed to load data (attempt ${retries + 1}/${maxRetries}):`, error);
          retries++;
          
          if (retries >= maxRetries) {
            // Final attempt failed - show error to user
            alert("Failed to load trips. Please refresh the page.");
            return;
          }
          
          // Wait before retry
          await new Promise(resolve => setTimeout(resolve, 1000 * retries));
        }
      }
    }
    loadData();
  }, []);

  useEffect(() => {
    async function loadCurrentUser() {
      try {
        const {
          data: { user },
        } = await supabase.auth.getUser();
        if (user) {
          setCurrentUserId(user.id);
          const { data: memberData } = await supabase
            .from("members")
            .select("display_name,full_name")
            .eq("id", user.id)
            .maybeSingle();
          const name = memberData?.display_name || memberData?.full_name || null;
          setCurrentUserName(name);
        }
      } catch (error) {
        console.warn("Failed to load current user:", error);
      }
    }
    loadCurrentUser();
  }, [supabase]);

  const today = new Date().toISOString().slice(0, 10);

  const nextTrip = useMemo(() => {
    // Upcoming trips: Scheduled, Open for Signups, Signups Closed, Game Day (before trip date or trip date passed but no results yet)
    const upcoming = [...trips]
      .filter((t) => t.date >= today && !t.result)
      .sort((a, b) => a.date.localeCompare(b.date));
    return upcoming[0] ?? null;
  }, [trips, today]);
  
  // Current trip: Game Day (trip date passed, no results yet)
  const currentTrip = useMemo(() => {
    const current = [...trips]
      .filter((t) => t.date < today && !t.result)
      .sort((a, b) => b.date.localeCompare(a.date)); // Most recent first
    return current[0] ?? null;
  }, [trips, today]);

  // Show current trip (Game Day) if no upcoming trip
  const displayTrip = nextTrip || currentTrip;
  
  if (!displayTrip) {
    return (
      <div className="rounded-xl border bg-white p-5 shadow-sm">
        <div className="text-lg font-semibold text-gray-900">No upcoming trips</div>
        <div className="mt-2 text-sm text-gray-600">
          When the admin creates the next outing, it'll appear here.
        </div>
        <div className="mt-4">
          <Link href="/trips" className="text-sm text-gray-700 hover:text-gray-900">
            Go to Trips →
          </Link>
        </div>
      </div>
    );
  }
  
  const isCurrentTrip = displayTrip === currentTrip;

  const courseText = getTripCourseText(displayTrip, courses);
  const course = displayTrip.courseId
    ? courses.find((c) => c.id === displayTrip.courseId)
    : undefined;
  const myEntry =
    currentUserId
      ? displayTrip.attendees.find((a) => a.memberId && a.memberId === currentUserId)
      : currentUserName
      ? displayTrip.attendees.find((a) => a.name === currentUserName)
      : undefined;

  // Scheduled: open trip, but signups only open within 30 days of trip date
  const tripDateUtc = new Date(displayTrip.date + "T00:00:00Z").getTime();
  const signupOpenUtc = Number.isFinite(tripDateUtc)
    ? tripDateUtc - 30 * 24 * 60 * 60 * 1000
    : NaN;
  const signupOpenDateYmd = Number.isFinite(signupOpenUtc)
    ? new Date(signupOpenUtc).toISOString().slice(0, 10)
    : null;
  const isScheduled =
    displayTrip.status === "open" &&
    !displayTrip.result &&
    Number.isFinite(signupOpenUtc) &&
    Date.now() < signupOpenUtc;
  
  // Check if cutoff has passed (11:59pm SGT)
  const cutoffPassed = displayTrip.cutoffAt ? (() => {
    const cutoff = new Date(displayTrip.cutoffAt);
    const now = new Date();
    const sgtOffset = 8 * 60 * 60 * 1000;
    const nowSGT = new Date(now.getTime() + sgtOffset);
    return nowSGT > cutoff;
  })() : false;
  
  const joinDisabled = isScheduled || displayTrip.status !== "open" || cutoffPassed || isCurrentTrip;

  async function handleImIn() {
    // Prevent duplicate joins
    if (myEntry) return;
    if (joinDisabled) {
      if (isScheduled && signupOpenDateYmd) {
        alert(`Signups open on ${signupOpenDateYmd} (30 days before the trip).`);
      } else if (displayTrip.status === "cancelled") {
        alert("This trip has been cancelled.");
      } else if (isCurrentTrip) {
        alert("This trip is in progress. Signups are closed.");
      } else if (cutoffPassed) {
        alert("Signups have closed (cutoff date has passed).");
      } else {
        alert("Signups are not open for this trip.");
      }
      return;
    }

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (user) {
        // Look up existing member to get current handicap
        const { data: memberData } = await supabase
          .from("members")
          .select("full_name,display_name,nationality,declared_handicap")
          .eq("id", user.id)
          .maybeSingle();

        const existingHandicap =
          memberData && typeof memberData.declared_handicap === "number"
            ? memberData.declared_handicap
            : null;

        // Prepare the join action function
        const continueWithHandicap = async (handicapValue: number | null) => {
          try {
            const now = new Date().toISOString();

            if (memberData) {
              await supabase
                .from("members")
                .update({
                  declared_handicap: handicapValue,
                  last_seen: now,
                  full_name: memberData.full_name ?? null,
                  display_name: memberData.display_name ?? null,
                  nationality: memberData.nationality ?? null,
                })
                .eq("id", user.id);
            } else {
              await supabase
                .from("members")
                .insert({
                  id: user.id,
                  email: user.email || "",
                  declared_handicap: handicapValue,
                  last_seen: now,
                  created_at: now,
                });
            }

            // Add to trip and save handicap for this trip
            const updated = await joinTrip(trips, displayTrip.id, handicapValue);
            setTrips(updated);
            
            // Reload trips to get latest data (with a small delay to let DB catch up)
            try {
              await new Promise(resolve => setTimeout(resolve, 500));
              const freshTrips = await loadTrips(true); // Bypass cache
              setTrips(freshTrips);
              
              // Silently verify - only log warnings, don't show errors to user
              // The join likely succeeded even if verification fails due to timing/name matching
              const freshDisplayTrip = freshTrips.find(t => t.id === displayTrip.id);
              if (freshDisplayTrip && currentUserName) {
                const freshMyEntry = freshDisplayTrip.attendees.find((a) => 
                  a.name === currentUserName || 
                  a.name === memberData?.display_name || 
                  a.name === memberData?.full_name
                );
                if (!freshMyEntry) {
                  console.warn("Join verification: name not found in attendees, but join may have succeeded");
                }
              }
            } catch (reloadError) {
              console.error("Failed to reload trips after join:", reloadError);
              // Don't show error to user - the join might have succeeded
            }
          } catch (error) {
            console.error("Failed to join trip:", error);
            alert(
              `Failed to join trip: ${error instanceof Error ? error.message : String(error)}\n\nPlease try again or refresh the page.`
            );
          }
        };

        // Ask if they want to edit their current handicap
        if (existingHandicap !== null) {
          // Show confirm modal to ask if they want to edit
          setConfirmModal({
            isOpen: true,
            title: "Edit handicap?",
            message: `Your current handicap is ${existingHandicap}. Do you want to edit it before joining this trip?`,
            onConfirm: () => {
              setConfirmModal({ ...confirmModal, isOpen: false });
              // Show prompt modal for editing handicap
              setPromptModal({
                isOpen: true,
                title: "Enter handicap",
                message: "Enter your handicap for this trip (0–36), or leave blank to keep it the same:",
                defaultValue: String(existingHandicap),
                placeholder: "0–36",
                onConfirm: (input: string) => {
                  setPromptModal({ ...promptModal, isOpen: false });
                  const trimmed = input.trim();
                  let handicapValue: number | null = existingHandicap;
                  if (trimmed === "") {
                    handicapValue = existingHandicap;
                  } else {
                    const parsed = Number(trimmed);
                    if (!Number.isFinite(parsed) || parsed < 0 || parsed > 36) {
                      alert("Handicap must be a number between 0 and 36.");
                      return;
                    }
                    handicapValue = parsed;
                  }
                  void continueWithHandicap(handicapValue);
                },
                onCancel: () => {
                  setPromptModal({ ...promptModal, isOpen: false });
                  // Join with existing handicap even if they cancel the prompt
                  void continueWithHandicap(existingHandicap);
                },
              });
            },
            onCancel: () => {
              setConfirmModal({ ...confirmModal, isOpen: false });
              // Use existing handicap without editing
              void continueWithHandicap(existingHandicap);
            },
          });
        } else {
          // Show prompt modal for new handicap
          setPromptModal({
            isOpen: true,
                title: "Enter handicap",
                message: "Please enter your current handicap (0–36), or leave blank if you are not sure yet:",
            defaultValue: "",
            placeholder: "0–36",
            onConfirm: (input: string) => {
              setPromptModal({ ...promptModal, isOpen: false });
              const trimmed = input.trim();
              let handicapValue: number | null = null;
              if (trimmed !== "") {
                const parsed = Number(trimmed);
                if (!Number.isFinite(parsed) || parsed < 0 || parsed > 36) {
                  alert("Handicap must be a number between 0 and 36.");
                  return;
                }
                handicapValue = parsed;
              }
              void continueWithHandicap(handicapValue);
            },
            onCancel: () => {
              setPromptModal({ ...promptModal, isOpen: false });
              // Join without handicap
              void continueWithHandicap(null);
            },
          });
        }
      } else {
        alert("You must be signed in to join a trip.");
      }
    } catch (error) {
      console.error("Failed to start join process:", error);
      alert(
        `Failed to start join process: ${error instanceof Error ? error.message : String(error)}\n\nPlease try again or refresh the page.`
      );
    }
  }

  async function handleImOut() {
    setConfirmModal({
      isOpen: true,
      title: "Leave this trip?",
      message: "You'll be removed from the attendee list.",
      onConfirm: async () => {
        setConfirmModal({ ...confirmModal, isOpen: false });
        try {
          const updated = await leaveTrip(trips, displayTrip.id);
          setTrips(updated);
        } catch (error) {
          console.error("Failed to leave trip:", error);
          alert(`Failed to leave trip: ${error instanceof Error ? error.message : String(error)}`);
        }
      },
      onCancel: () => {
        setConfirmModal({ ...confirmModal, isOpen: false });
      },
    });
  }

  return (
    <div className="space-y-4">
      <TripCard
        trip={displayTrip}
        courseText={courseText}
        course={course}
        variant="home"
        headerLabel={isCurrentTrip ? "Current trip" : "Next trip"}
        isCurrentTrip={isCurrentTrip}
        isScheduled={isScheduled}
        signupOpenDateYmd={signupOpenDateYmd}
        myEntry={myEntry}
        joinDisabled={joinDisabled}
        onJoin={handleImIn}
        onLeave={handleImOut}
      />

      <div className="grid grid-cols-2 gap-3">
        <Link
          href="/trips"
          className="rounded-xl border bg-white p-4 text-sm text-gray-700 shadow-sm hover:bg-gray-50"
        >
          <div className="font-semibold text-gray-900">Trips</div>
          <div className="mt-1 text-gray-600">Upcoming + past</div>
        </Link>

        <Link
          href="/results"
          className="rounded-xl border bg-white p-4 text-sm text-gray-700 shadow-sm hover:bg-gray-50"
        >
          <div className="font-semibold text-gray-900">Results</div>
          <div className="mt-1 text-gray-600">Published only</div>
        </Link>
      </div>

      <ConfirmModal
        isOpen={confirmModal.isOpen}
        title={confirmModal.title}
        message={confirmModal.message}
        confirmLabel={confirmModal.title === "Leave this trip?" ? "Leave" : "Yes"}
        cancelLabel={confirmModal.title === "Leave this trip?" ? "Cancel" : "No"}
        confirmVariant={confirmModal.title === "Leave this trip?" ? "danger" : "primary"}
        onConfirm={confirmModal.onConfirm}
        onCancel={confirmModal.onCancel}
      />

      <PromptModal
        isOpen={promptModal.isOpen}
        title={promptModal.title}
        message={promptModal.message}
        defaultValue={promptModal.defaultValue}
        placeholder={promptModal.placeholder}
        confirmLabel="OK"
        cancelLabel="Cancel"
        onConfirm={promptModal.onConfirm}
        onCancel={promptModal.onCancel}
      />
    </div>
  );
}
