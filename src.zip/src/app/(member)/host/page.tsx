"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { createBrowserClient } from "@supabase/ssr";
import { loadCourses, type Course } from "../../lib/courseActions";
import { createTrip } from "../../lib/tripActions";

type MemberRow = {
  id: string;
  full_name: string | null;
  display_name: string | null;
};

type GroupRow = {
  id: string;
  name: string;
  slug: string;
};

export default function HostPage() {
  const router = useRouter();
  const [activeGroupId, setActiveGroupId] = useState<string | null>(null);
  const [approvedGroups, setApprovedGroups] = useState<GroupRow[]>([]);
  const [isProfileComplete, setIsProfileComplete] = useState<boolean | null>(null);
  const [courses, setCourses] = useState<Course[]>([]);
  const [members, setMembers] = useState<MemberRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentStep, setCurrentStep] = useState<"who" | "mode" | "planning" | "social" | "confirm">("who");
  
  // Step 1: WHO (multi-select)
  const [whoSelections, setWhoSelections] = useState<Set<"just_me" | "with_mates" | "open_to_groups">>(new Set());
  
  // Step 2: MODE
  const [playMode, setPlayMode] = useState<"playing_now" | "planning_ahead" | null>(null);
  
  // Step 3B: Planning ahead - When & where
  const [tripDate, setTripDate] = useState("");
  const [tripTime, setTripTime] = useState("Now");
  const [selectedCourseId, setSelectedCourseId] = useState<string | null>(null);
  
  // Step 4: Social details
  const [selectedMemberIds, setSelectedMemberIds] = useState<string[]>([]);
  const [selectedGroupIds, setSelectedGroupIds] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  
  // Submission
  const [submitting, setSubmitting] = useState(false);
  const [createdTripId, setCreatedTripId] = useState<number | null>(null);

  const supabase = useMemo(() => {
    return createBrowserClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
    );
  }, []);

  useEffect(() => {
    document.title = "DayForeIt - Host a round";
  }, []);

  // Bootstrap: load activeGroupId, approvedGroups, profile status
  useEffect(() => {
    async function loadBootstrap() {
      try {
        const res = await fetch("/api/me/bootstrap", { credentials: "include" });
        if (!res.ok) {
          if (res.status === 401) {
            router.replace("/login");
            return;
          }
          throw new Error("Failed to load bootstrap data");
        }
        const bootstrap = await res.json();
        setActiveGroupId(bootstrap.activeGroupId);
        setApprovedGroups(bootstrap.approvedGroups || []);
        setIsProfileComplete(bootstrap.isProfileComplete);
        
        // Check profile completion - route to profile if incomplete
        if (bootstrap.isProfileComplete === false) {
          router.push("/me/edit?required=true&returnTo=/host");
          return;
        }
      } catch (error) {
        console.error("Failed to load bootstrap:", error);
      } finally {
        setLoading(false);
      }
    }
    loadBootstrap();
  }, [router]);

  // Load courses
  useEffect(() => {
    async function loadCoursesData() {
      const coursesData = await loadCourses();
      setCourses(coursesData);
    }
    loadCoursesData();
  }, []);

  // Load members from all approved groups (cross-group)
  useEffect(() => {
    if (approvedGroups.length === 0) return;
    
    async function loadMembers() {
      try {
        const groupIds = approvedGroups.map((g) => g.id);
        
        // Get user IDs from all approved groups
        const { data: groupMembersData, error: groupMembersError } = await supabase
          .from("group_members")
          .select("user_id")
          .in("group_id", groupIds)
          .eq("status", "approved");

        if (groupMembersError || !groupMembersData || groupMembersData.length === 0) {
          setMembers([]);
          return;
        }

        // Get unique user IDs
        const userIds = Array.from(new Set(groupMembersData.map((gm) => gm.user_id)));

        // Fetch member details
        const { data: membersData, error: membersError } = await supabase
          .from("members")
          .select("id,full_name,display_name")
          .in("id", userIds)
          .order("full_name", { ascending: true, nullsFirst: false });

        if (membersError) {
          console.error("Failed to load members:", membersError);
          setMembers([]);
        } else {
          setMembers(membersData || []);
        }
      } catch (error) {
        console.error("Error loading members:", error);
        setMembers([]);
      }
    }
    loadMembers();
  }, [supabase, approvedGroups]);

  function toggleWho(option: "just_me" | "with_mates" | "open_to_groups") {
    setWhoSelections((prev) => {
      const next = new Set(prev);
      if (option === "just_me") {
        // Just me is exclusive
        if (next.has("just_me")) {
          return next; // Already selected, do nothing
        }
        return new Set(["just_me"]);
      } else {
        // With mates and open to groups can coexist
        if (next.has("just_me")) {
          next.delete("just_me");
        }
        if (next.has(option)) {
          next.delete(option);
        } else {
          next.add(option);
        }
        // If nothing selected, default to just_me
        if (next.size === 0) {
          return new Set(["just_me"]);
        }
        return next;
      }
    });
    // Auto-advance to Step 2 (MODE) after selection
    setCurrentStep("mode");
  }

  function getWeekday(dateStr: string): string {
    if (!dateStr) return "";
    const date = new Date(dateStr + "T00:00:00");
    return date.toLocaleDateString("en-GB", { weekday: "long" });
  }

  function generateDefaultName(): string {
    if (tripDate) {
      const weekday = getWeekday(tripDate);
      return `${weekday} round`;
    }
    if (selectedCourseId) {
      const course = courses.find((c) => c.id === selectedCourseId);
      if (course) {
        return `${course.name} round`;
      }
    }
    return "Round";
  }

  async function handlePlayingNow() {
    if (!activeGroupId) {
      alert("No active group found. Please refresh and try again.");
      return;
    }

    setSubmitting(true);

    try {
      const today = new Date().toISOString().slice(0, 10);
      const tripName = "Playing now";

      const result = await createTrip([], activeGroupId, {
        name: tripName,
        date: today,
        format: "Stableford",
        status: "open",
        courseId: null, // Allowed for playing now
        teeId: null,
        capacity: 4,
        tripOrigin: "member",
        isPostedToGroup: whoSelections.has("open_to_groups"),
        scenarioKey: null,
        logistics: undefined,
      });

      if (result.newTripId) {
        // Route to GameDay
        router.push(`/gameday/${result.newTripId}`);
      } else {
        throw new Error("Round created but no ID returned");
      }
    } catch (error) {
      console.error("Failed to create round:", error);
      alert(`Failed to create round: ${error instanceof Error ? error.message : String(error)}`);
      setSubmitting(false);
    }
  }

  async function handleSubmit() {
    if (!activeGroupId) {
      alert("No active group found. Please refresh and try again.");
      return;
    }

    if (!tripDate) {
      alert("Please select a date.");
      return;
    }

    if (!selectedCourseId) {
      alert("Please select a course.");
      return;
    }

    setSubmitting(true);

    try {
      const tripName = generateDefaultName();
      const isPostedToGroup = whoSelections.has("open_to_groups");
      const finalCapacity = 4; // Default capacity

      const result = await createTrip([], activeGroupId, {
        name: tripName,
        date: tripDate,
        format: "Stableford",
        status: "open",
        courseId: selectedCourseId,
        teeId: null,
        capacity: finalCapacity,
        tripOrigin: "member",
        isPostedToGroup: isPostedToGroup,
        scenarioKey: null,
        logistics: undefined,
      });

      if (result.newTripId) {
        setCreatedTripId(result.newTripId);
        setCurrentStep("confirm");
      } else {
        throw new Error("Round created but no ID returned");
      }
    } catch (error) {
      console.error("Failed to create round:", error);
      alert(`Failed to create round: ${error instanceof Error ? error.message : String(error)}`);
      setSubmitting(false);
    }
  }

  function toggleMember(memberId: string) {
    setSelectedMemberIds((prev) =>
      prev.includes(memberId)
        ? prev.filter((id) => id !== memberId)
        : [...prev, memberId]
    );
  }

  function toggleGroup(groupId: string) {
    setSelectedGroupIds((prev) =>
      prev.includes(groupId)
        ? prev.filter((id) => id !== groupId)
        : [...prev, groupId]
    );
  }

  // Filter members by search query
  const filteredMembers = useMemo(() => {
    if (!searchQuery.trim()) return members;
    const query = searchQuery.toLowerCase();
    return members.filter((m) => {
      const displayName = (m.display_name || m.full_name || "").toLowerCase();
      const fullName = (m.full_name || "").toLowerCase();
      return displayName.includes(query) || fullName.includes(query);
    });
  }, [members, searchQuery]);

  if (loading) {
    return (
      <div className="container mx-auto max-w-2xl px-4 py-8">
        <div className="rounded-xl border border-border bg-surface p-8 text-center">
          <p className="text-sm text-muted">Loading…</p>
        </div>
      </div>
    );
  }

  if (!activeGroupId) {
    return (
      <div className="container mx-auto max-w-2xl px-4 py-8">
        <div className="rounded-xl border border-border bg-surface p-8 text-center">
          <p className="text-sm text-muted">No active group found. Please join a group first.</p>
        </div>
      </div>
    );
  }

  // Step 1: WHO (first, always)
  if (currentStep === "who") {
    return (
      <div className="container mx-auto max-w-2xl px-4 py-8">
        <div className="mb-6">
          <h1 className="text-2xl font-semibold text-foreground">Host a round</h1>
          <p className="mt-2 text-sm text-muted">Who are you playing with?</p>
        </div>

        <div className="space-y-3">
          <button
            onClick={() => toggleWho("just_me")}
            className={`w-full rounded-lg border p-4 text-left transition-colors ${
              whoSelections.has("just_me")
                ? "border-brand-green bg-brand-green/10"
                : "border-border bg-surface hover:bg-muted/50"
            }`}
          >
            <div className="font-medium text-foreground">🧍 Just me</div>
          </button>

          <button
            onClick={() => toggleWho("with_mates")}
            className={`w-full rounded-lg border p-4 text-left transition-colors ${
              whoSelections.has("with_mates")
                ? "border-brand-green bg-brand-green/10"
                : "border-border bg-surface hover:bg-muted/50"
            }`}
          >
            <div className="font-medium text-foreground">👥 With mates</div>
          </button>

          <button
            onClick={() => toggleWho("open_to_groups")}
            className={`w-full rounded-lg border p-4 text-left transition-colors ${
              whoSelections.has("open_to_groups")
                ? "border-brand-green bg-brand-green/10"
                : "border-border bg-surface hover:bg-muted/50"
            }`}
          >
            <div className="font-medium text-foreground">🌍 Open to groups</div>
          </button>
        </div>

        <div className="mt-6">
          <button
            onClick={() => router.back()}
            className="w-full rounded-lg border border-border bg-surface px-4 py-2 text-sm font-medium text-foreground hover:bg-muted/50"
          >
            Cancel
          </button>
        </div>
      </div>
    );
  }

  // Step 2: MODE OF PLAY
  if (currentStep === "mode") {
    return (
      <div className="container mx-auto max-w-2xl px-4 py-8">
        <div className="mb-6">
          <h1 className="text-2xl font-semibold text-foreground">When are you playing?</h1>
        </div>

        <div className="space-y-3">
          <button
            onClick={handlePlayingNow}
            disabled={submitting}
            className="w-full rounded-lg border border-brand-green bg-brand-green/10 p-4 text-left transition-colors hover:bg-brand-green/20 disabled:opacity-50"
          >
            <div className="font-medium text-foreground">▶️ Playing now</div>
            {submitting && <div className="mt-1 text-sm text-muted">Creating round…</div>}
          </button>

          <button
            onClick={() => {
              setPlayMode("planning_ahead");
              setCurrentStep("planning");
            }}
            className="w-full rounded-lg border border-border bg-surface p-4 text-left transition-colors hover:bg-muted/50"
          >
            <div className="font-medium text-foreground">🗓️ Planning ahead</div>
          </button>
        </div>

        <div className="mt-6">
          <button
            onClick={() => {
              setCurrentStep("who");
              setWhoSelections(new Set());
            }}
            className="w-full rounded-lg border border-border bg-surface px-4 py-2 text-sm font-medium text-foreground hover:bg-muted/50"
          >
            Back
          </button>
        </div>
      </div>
    );
  }

  // Step 3B: PLANNING AHEAD - When & where (combined)
  if (currentStep === "planning") {
    return (
      <div className="container mx-auto max-w-2xl px-4 py-8">
        <div className="mb-6">
          <h1 className="text-2xl font-semibold text-foreground">When & where</h1>
        </div>

        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              Date <span className="text-muted">(required)</span>
            </label>
            <input
              type="date"
              value={tripDate}
              onChange={(e) => setTripDate(e.target.value)}
              className="w-full rounded-lg border border-border bg-surface px-4 py-2 text-foreground"
              min={new Date().toISOString().split("T")[0]}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              Time
            </label>
            <input
              type="text"
              value={tripTime}
              onChange={(e) => setTripTime(e.target.value)}
              placeholder="Now"
              className="w-full rounded-lg border border-border bg-surface px-4 py-2 text-foreground"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              Course <span className="text-muted">(required)</span>
            </label>
            <select
              value={selectedCourseId || ""}
              onChange={(e) => setSelectedCourseId(e.target.value || null)}
              className="w-full rounded-lg border border-border bg-surface px-4 py-2 text-foreground"
            >
              <option value="">Select a course</option>
              {courses.map((course) => (
                <option key={course.id} value={course.id}>
                  {course.name} {course.location ? `- ${course.location}` : ""}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="mt-6 flex gap-3">
          <button
            onClick={() => {
              setCurrentStep("mode");
              setPlayMode(null);
            }}
            className="flex-1 rounded-lg border border-border bg-surface px-4 py-2 text-sm font-medium text-foreground hover:bg-muted/50"
          >
            Back
          </button>
          <button
            onClick={() => {
              // Check if we need social details step
              if (whoSelections.has("with_mates") || whoSelections.has("open_to_groups")) {
                setCurrentStep("social");
              } else {
                handleSubmit();
              }
            }}
            disabled={!tripDate || !selectedCourseId || submitting}
            className="flex-1 rounded-lg bg-brand-green px-4 py-2 text-sm font-medium text-white disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {submitting ? "Creating…" : "Host round"}
          </button>
        </div>
      </div>
    );
  }

  // Step 4: SOCIAL DETAILS (conditional)
  if (currentStep === "social") {
    return (
      <div className="container mx-auto max-w-2xl px-4 py-8">
        <div className="mb-6">
          <h1 className="text-2xl font-semibold text-foreground">Add details</h1>
        </div>

        <div className="space-y-6">
          {/* Add mates section */}
          {whoSelections.has("with_mates") && (
            <div>
              <label className="block text-sm font-medium text-foreground mb-3">
                Add mates
              </label>
              
              {/* Search */}
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search members..."
                className="w-full rounded-lg border border-border bg-surface px-4 py-2 text-sm text-foreground mb-3"
              />

              {/* Member list */}
              <div className="space-y-2 max-h-60 overflow-y-auto border border-border rounded-lg p-3 bg-surface">
                {filteredMembers.length === 0 ? (
                  <p className="text-sm text-muted">No members found</p>
                ) : (
                  filteredMembers.map((member) => {
                    const isSelected = selectedMemberIds.includes(member.id);
                    const displayName = member.display_name || member.full_name || "Unknown";
                    return (
                      <button
                        key={member.id}
                        onClick={() => toggleMember(member.id)}
                        className={`w-full rounded-lg border p-3 text-left transition-colors ${
                          isSelected
                            ? "border-brand-green bg-brand-green/10"
                            : "border-border bg-surface hover:bg-muted/50"
                        }`}
                      >
                        <div className="text-sm font-medium text-foreground">{displayName}</div>
                      </button>
                    );
                  })
                )}
              </div>
            </div>
          )}

          {/* Open to groups section */}
          {whoSelections.has("open_to_groups") && (
            <div>
              <label className="block text-sm font-medium text-foreground mb-3">
                Post to groups
              </label>
              <div className="space-y-2">
                {approvedGroups.map((group) => {
                  const isSelected = selectedGroupIds.includes(group.id);
                  return (
                    <button
                      key={group.id}
                      onClick={() => toggleGroup(group.id)}
                      className={`w-full rounded-lg border p-3 text-left transition-colors ${
                        isSelected
                          ? "border-brand-green bg-brand-green/10"
                          : "border-border bg-surface hover:bg-muted/50"
                      }`}
                    >
                      <div className="text-sm font-medium text-foreground">{group.name}</div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        <div className="mt-6 flex gap-3">
          <button
            onClick={() => setCurrentStep("planning")}
            className="flex-1 rounded-lg border border-border bg-surface px-4 py-2 text-sm font-medium text-foreground hover:bg-muted/50"
          >
            Back
          </button>
          <button
            onClick={handleSubmit}
            disabled={submitting}
            className="flex-1 rounded-lg bg-brand-green px-4 py-2 text-sm font-medium text-white disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {submitting ? "Creating…" : "Host round"}
          </button>
        </div>
      </div>
    );
  }

  // Step 5: CONFIRMATION (shown after successful creation)
  if (currentStep === "confirm" && createdTripId) {
    return (
      <div className="container mx-auto max-w-2xl px-4 py-8">
        <div className="mb-6">
          <h1 className="text-2xl font-semibold text-foreground">Round hosted</h1>
        </div>

        <div className="rounded-xl border border-border bg-surface p-6 space-y-4">
          <div className="text-sm text-muted">
            Your round is ready. Share it with your mates or start playing.
          </div>

          <div className="flex gap-3">
            <Link
              href={`/trips/${createdTripId}`}
              className="flex-1 rounded-lg bg-brand-green px-4 py-2 text-sm font-medium text-white hover:opacity-90 text-center"
            >
              View round
            </Link>
            {whoSelections.has("with_mates") && (
              <button
                onClick={() => {
                  const inviteLink = `${window.location.origin}/trips/${createdTripId}?invite=1`;
                  navigator.clipboard.writeText(inviteLink);
                  alert("Invite link copied!");
                }}
                className="flex-1 rounded-lg border border-border bg-surface px-4 py-2 text-sm font-medium text-foreground hover:bg-muted/50"
              >
                Copy invite link
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  return null;
}
