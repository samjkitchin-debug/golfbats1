/**
 * GameDay Instrument Types
 * 
 * Type definitions for the GameDay instrument registry system.
 */

import type { GameDayContext, GameDayInstrumentKey } from "../gamedayTypes";
import type { GameDayPolicy } from "../gamedayPolicy";

export type GameDayInstrumentRenderProps = {
  ctx: GameDayContext;
  policy: GameDayPolicy;
  // Add other props as needed for instrument bodies
  [key: string]: any;
};

export type GameDayInstrumentDefinition = {
  key: GameDayInstrumentKey;
  title: string;
  helper?: string;
  isAvailable: (ctx: GameDayContext) => boolean;
  RenderBody: (props: GameDayInstrumentRenderProps) => JSX.Element;
  RightAction?: (props: GameDayInstrumentRenderProps) => JSX.Element | null;
};
