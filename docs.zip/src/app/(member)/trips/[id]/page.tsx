"use client";

import Link from "next/link";
import { useParams, useRouter, useSearchParams } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { createBrowserClient } from "@supabase/ssr";
import { loadCourses, type Course } from "../../../lib/courseActions";
import {
  isTripLocked,
  joinTrip,
  leaveTrip,
  loadTrips,
  setMyHandicapForTrip,
  type Trip,
} from "../../../lib/tripActions";
import { getTripCourseText, formatTripDateLong } from "../../../lib/tripDisplay";
import { ConfirmModal } from "../../../components/ConfirmModal";
import { PromptModal } from "../../../components/PromptModal";
import { TripRsvpActions } from "../../../components/TripRsvpActions";
import { perfMark, perfMeasure, perfLog } from "../../../lib/perf";
import { checkMemberExportReadiness } from "../../../lib/memberExportReadiness";
import { getGolfNoun } from "../../../lib/roundNounHelper";

function toTripId(raw: string): number | null {
  const n = Number(raw);
  return Number.isFinite(n) ? n : null;
}

// Helper to convert meetTime string to HH:MM format for time input
function convertToTimeInputFormat(timeStr: string | undefined): string {
  if (!timeStr) return "";
  
  // If already in HH:MM format, return as-is
  if (/^\d{2}:\d{2}$/.test(timeStr)) return timeStr;
  
  // Try to parse formats like "7:30am", "7:30 AM", "07:30", etc.
  const match = timeStr.match(/(\d{1,2}):(\d{2})\s*(am|pm|AM|PM)?/i);
  if (match) {
    let hours = parseInt(match[1], 10);
    const minutes = match[2];
    const period = match[3]?.toLowerCase();
    
    if (period === "pm" && hours !== 12) {
      hours += 12;
    } else if (period === "am" && hours === 12) {
      hours = 0;
    }
    
    return `${hours.toString().padStart(2, "0")}:${minutes}`;
  }
  
  // If no match, return empty (user will need to re-enter)
  return "";
}

// Helper to check if trip is a hosted round
function isHostedRound(trip: Trip): boolean {
  return trip.scenarioKey === "hosted_round" || trip.tripOrigin === "member";
}

// Helper to check if trip is a group trip
function isGroupTrip(trip: Trip): boolean {
  return trip.tripOrigin === "group" || (trip.scenarioKey !== "hosted_round" && trip.tripOrigin !== "member");
}

// Meet details editor component (host only)
function MeetDetailsEditor({
  trip,
  currentUserId,
  supabase,
  activeGroupId,
  onUpdate,
}: {
  trip: Trip;
  currentUserId: string | null;
  supabase: ReturnType<typeof createBrowserClient>;
  activeGroupId: string | null;
  onUpdate: (updatedTrip: Trip) => void;
}) {
  const rawMeetTime = (trip.decisionLogistics?.meetTime || trip.logistics?.meetTime)?.trim() || "";
  const [meetTime, setMeetTime] = useState(convertToTimeInputFormat(rawMeetTime));
  const [meetingPoint, setMeetingPoint] = useState(
    (trip.decisionLogistics?.meetingPoint || trip.logistics?.meetingPoint)?.trim() || ""
  );
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  async function handleSave() {
    if (saving || !currentUserId || !activeGroupId) return;

    setSaving(true);
    setSaved(false);

    try {
      // Update trip in database by legacy_id (Trip.id is numeric legacy_id)
      const { error } = await supabase
        .from("trips")
        .update({
          meet_time: meetTime.trim() || null,
          meeting_point: meetingPoint.trim() || null,
        })
        .eq("legacy_id", trip.id);

      if (error) {
        throw error;
      }

      // Reload trips to get fresh data
      const freshTrips = await loadTrips(activeGroupId, true); // Bypass cache
      const updatedTrip = freshTrips.find(t => t.id === trip.id);
      
      if (updatedTrip) {
        onUpdate(updatedTrip);
      } else {
        // Fallback: update local state if reload didn't find the trip
        const fallbackTrip: Trip = {
          ...trip,
          logistics: {
            ...trip.logistics,
            meetTime: meetTime.trim() || undefined,
            meetingPoint: meetingPoint.trim() || undefined,
          },
          decisionLogistics: {
            ...trip.decisionLogistics,
            meetTime: meetTime.trim() || undefined,
            meetingPoint: meetingPoint.trim() || undefined,
          },
        };
        onUpdate(fallbackTrip);
      }

      setSaved(true);
      
      // Clear saved state after 2 seconds
      setTimeout(() => setSaved(false), 2000);
    } catch (error) {
      console.error("Failed to save meet details:", error);
      alert(`Failed to save meet details: ${error instanceof Error ? error.message : String(error)}`);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-3">
      <div>
        <div className="text-xs font-semibold mb-1">Meet time</div>
        <input
          type="time"
          value={meetTime}
          onChange={(e) => {
            setMeetTime(e.target.value);
            setSaved(false);
          }}
          placeholder="e.g. 7:30am"
          className="w-full rounded-xl border border-border px-3 py-2 text-sm outline-none focus:border-foreground/30"
        />
      </div>
      <div>
        <div className="text-xs font-semibold mb-1">Meeting point</div>
        <input
          type="text"
          value={meetingPoint}
          onChange={(e) => {
            setMeetingPoint(e.target.value);
            setSaved(false);
          }}
          placeholder="e.g. Tanah Merah Ferry Terminal"
          className="w-full rounded-xl border border-border px-3 py-2 text-sm outline-none focus:border-foreground/30"
        />
      </div>
      <div className="flex items-center gap-2">
        <button
          onClick={handleSave}
          disabled={saving}
          className="rounded-xl btn-primary px-4 py-2 text-sm font-medium text-white hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {saving ? "Saving..." : saved ? "Saved" : "Save"}
        </button>
        {saved && (
          <span className="text-xs text-muted">Saved</span>
        )}
      </div>
    </div>
  );
}

// Hosted round meet details instrument
function HostedRoundMeetDetailsInstrument({
  trip,
  currentUserId,
  supabase,
  activeGroupId,
  onUpdate,
}: {
  trip: Trip;
  currentUserId: string | null;
  supabase: ReturnType<typeof createBrowserClient>;
  activeGroupId: string | null;
  onUpdate: (updatedTrip: Trip) => void;
}) {
  const rawMeetTime = (trip.decisionLogistics?.meetTime || trip.logistics?.meetTime)?.trim() || "";
  const defaultTime = rawMeetTime ? convertToTimeInputFormat(rawMeetTime) : "07:00";
  const [meetTime, setMeetTime] = useState(defaultTime);
  const [meetingPoint, setMeetingPoint] = useState(
    (trip.decisionLogistics?.meetingPoint || trip.logistics?.meetingPoint)?.trim() || ""
  );
  const [note, setNote] = useState(
    (trip.decisionLogistics?.notes || trip.logistics?.notes)?.trim() || ""
  );
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  async function handleSave() {
    if (saving || !currentUserId || !activeGroupId) return;

    setSaving(true);
    setSaved(false);

    try {
      // Update trip in database - save all three fields together
      const { error } = await supabase
        .from("trips")
        .update({
          meet_time: meetTime.trim() || null,
          meeting_point: meetingPoint.trim() || null,
          notes: note.trim() || null,
        })
        .eq("legacy_id", trip.id);

      if (error) {
        throw error;
      }

      // Reload trips to get fresh data
      const freshTrips = await loadTrips(activeGroupId, true);
      const updatedTrip = freshTrips.find(t => t.id === trip.id);
      
      if (updatedTrip) {
        onUpdate(updatedTrip);
      } else {
        // Fallback: update local state
        const fallbackTrip: Trip = {
          ...trip,
          logistics: {
            ...trip.logistics,
            meetTime: meetTime.trim() || undefined,
            meetingPoint: meetingPoint.trim() || undefined,
            notes: note.trim() || undefined,
          },
          decisionLogistics: {
            ...trip.decisionLogistics,
            meetTime: meetTime.trim() || undefined,
            meetingPoint: meetingPoint.trim() || undefined,
            notes: note.trim() || undefined,
          },
        };
        onUpdate(fallbackTrip);
      }

      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch (error) {
      console.error("Failed to save meet details:", error);
      alert(`Failed to save meet details: ${error instanceof Error ? error.message : String(error)}`);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-3">
      <div>
        <div className="text-xs font-semibold mb-1">Meet time</div>
        <input
          type="time"
          value={meetTime}
          onChange={(e) => {
            setMeetTime(e.target.value);
            setSaved(false);
          }}
          className="w-full rounded-xl border border-border px-3 py-2 text-sm outline-none focus:border-foreground/30"
        />
      </div>
      <div>
        <div className="text-xs font-semibold mb-1">Where to meet</div>
        <input
          type="text"
          value={meetingPoint}
          onChange={(e) => {
            setMeetingPoint(e.target.value);
            setSaved(false);
          }}
          placeholder="e.g. Course clubhouse"
          className="w-full rounded-xl border border-border px-3 py-2 text-sm outline-none focus:border-foreground/30"
        />
      </div>
      <div>
        <div className="text-xs font-semibold mb-1">Note</div>
        <textarea
          value={note}
          onChange={(e) => {
            setNote(e.target.value);
            setSaved(false);
          }}
          placeholder="Anything else your group should know?"
          className="w-full rounded-xl border border-border px-3 py-2 text-sm outline-none focus:border-foreground/30 resize-none"
          rows={3}
        />
        <div className="mt-1 text-xs text-muted">
          e.g. Mike will pick us up and we'll head off together.
        </div>
      </div>
      <div className="flex items-center gap-2">
        <button
          onClick={handleSave}
          disabled={saving}
          className="rounded-xl btn-primary px-4 py-2 text-sm font-medium text-white hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {saving ? "Saving..." : saved ? "Saved" : "Save"}
        </button>
        {saved && (
          <span className="text-xs text-muted">Saved</span>
        )}
      </div>
    </div>
  );
}

// Travel instrument component (group trips only)
function TravelInstrument({
  trip,
  currentUserId,
  supabase,
  activeGroupId,
  onUpdate,
}: {
  trip: Trip;
  currentUserId: string | null;
  supabase: ReturnType<typeof createBrowserClient>;
  activeGroupId: string | null;
  onUpdate: (updatedTrip: Trip) => void;
}) {
  // Extract travel info from trip fields
  const travelTypeDetail = trip.travelType || null;
  const travelScope = trip.travelScope || null;
  const bookingApproach = trip.bookingApproach || null;
  const bookingProviderName = trip.bookingProviderName || "";
  const travelNote = trip.travelNote || "";

  const [editing, setEditing] = useState(false);
  const [travelType, setTravelType] = useState<"ferry" | "flight" | "coach" | "drive" | "other" | null>(travelTypeDetail);
  const [scope, setScope] = useState<"domestic" | "international" | null>(travelScope);
  const [bookingApproachState, setBookingApproachState] = useState<"self" | "centralised" | null>(bookingApproach);
  const [providerName, setProviderName] = useState(bookingProviderName);
  const [note, setNote] = useState(travelNote);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  // Update state when trip data changes
  useEffect(() => {
    if (!editing) {
      setTravelType(trip.travelType || null);
      setScope(trip.travelScope || null);
      setBookingApproachState(trip.bookingApproach || null);
      setProviderName(trip.bookingProviderName || "");
      setNote(trip.travelNote || "");
    }
  }, [trip.travelType, trip.travelScope, trip.bookingApproach, trip.bookingProviderName, trip.travelNote, editing]);

  const canEdit = trip.createdByMemberId === currentUserId;
  const hasTravelDetails = travelTypeDetail || travelScope || bookingApproach || travelNote.trim();

  async function handleSave() {
    if (saving || !currentUserId || !activeGroupId) return;

    setSaving(true);
    setSaved(false);

    try {
      // Update trip in database by legacy_id (Trip.id is numeric legacy_id)
      const { error } = await supabase
        .from("trips")
        .update({
          travel_involved: true,
          travel_type: travelType || null,
          travel_scope: scope || null,
          booking_approach: bookingApproachState || null,
          booking_provider_name: bookingApproachState === "centralised" ? (providerName.trim() || null) : null,
          travel_note: note.trim() || null,
        })
        .eq("legacy_id", trip.id);

      if (error) {
        throw error;
      }

      // Reload trips to get fresh data
      const freshTrips = await loadTrips(activeGroupId, true); // Bypass cache
      const updatedTrip = freshTrips.find(t => t.id === trip.id);
      
      if (updatedTrip) {
        onUpdate(updatedTrip);
      } else {
        // Fallback: update local state if reload didn't find the trip
        const fallbackTrip: Trip = {
          ...trip,
          travelInvolved: true,
          travelType: travelType || null,
          travelScope: scope || null,
          bookingApproach: bookingApproachState || null,
          bookingProviderName: bookingApproachState === "centralised" ? (providerName.trim() || null) : null,
          travelNote: note.trim() || null,
        };
        onUpdate(fallbackTrip);
      }

      setSaved(true);
      setEditing(false);
    } catch (error) {
      console.error("Failed to save travel details:", error);
      setSaved(false);
    } finally {
      setSaving(false);
    }
  }

  function getTravelTypeLabel(type: string | null): string {
    if (!type) return "";
    const labels: Record<string, string> = {
      ferry: "Ferry",
      flight: "Flight",
      coach: "Coach / bus",
      drive: "Drive",
      other: "Other",
    };
    return labels[type] || type;
  }

  if (!editing) {
    // Read-only view
    if (!hasTravelDetails) {
      if (!canEdit) {
        return (
          <section className="rounded-xl border bg-surface p-5 shadow-sm">
            <div className="text-sm font-medium text-foreground mb-1">Travel</div>
            <p className="text-sm text-muted">Travel details haven't been added yet.</p>
          </section>
        );
      }
      return (
        <section className="rounded-xl border bg-surface p-5 shadow-sm">
          <div className="text-sm font-medium text-foreground mb-1">Travel</div>
          <p className="text-sm text-muted mb-3">Travel details haven't been added yet.</p>
          <button
            onClick={() => setEditing(true)}
            className="rounded-lg btn-primary px-4 py-2 text-sm font-medium text-white hover:opacity-90"
          >
            Add travel details
          </button>
        </section>
      );
    }

    // Show summary
    return (
      <section className="rounded-xl border bg-surface p-5 shadow-sm">
        <div className="text-sm font-medium text-foreground mb-3">Travel</div>
        <div className="space-y-2 text-sm">
          {travelTypeDetail && (
            <div>
              <span className="text-muted">Travel type:</span> <span className="text-foreground">{getTravelTypeLabel(travelTypeDetail)}</span>
            </div>
          )}
          {travelScope && (
            <div>
              <span className="text-muted">Scope:</span> <span className="text-foreground">{travelScope.charAt(0).toUpperCase() + travelScope.slice(1)}</span>
            </div>
          )}
          {bookingApproach && (
            <div>
              <span className="text-muted">Booking:</span> <span className="text-foreground">
                {bookingApproach === "self" ? "Everyone books their own" : "Centralised booking"}
              </span>
            </div>
          )}
          {bookingApproach === "centralised" && bookingProviderName && (
            <div>
              <span className="text-muted">Booked via:</span> <span className="text-foreground">{bookingProviderName}</span>
            </div>
          )}
          {travelNote && (
            <div className="pt-2 border-t border-border">
              <div className="text-muted text-xs mb-1">Note</div>
              <div className="text-foreground whitespace-pre-wrap">{travelNote}</div>
            </div>
          )}
        </div>
        {canEdit && (
          <button
            onClick={() => setEditing(true)}
            className="mt-4 rounded-lg border border-border bg-transparent px-4 py-2 text-sm font-medium text-foreground hover:bg-surface"
          >
            Edit travel details
          </button>
        )}
      </section>
    );
  }

  // Edit view
  return (
    <section className="rounded-xl border bg-surface p-5 shadow-sm">
      <div className="text-sm font-medium text-foreground mb-4">Travel</div>
      <div className="space-y-4">
        {/* Travel type */}
        <div>
          <div className="text-xs font-semibold mb-2">Travel type</div>
          <div className="grid grid-cols-2 gap-2">
            {(["ferry", "flight", "coach", "drive", "other"] as const).map((type) => (
              <button
                key={type}
                onClick={() => setTravelType(type)}
                className={`rounded-lg border p-2 text-sm font-medium transition-all ${
                  travelType === type
                    ? "border-foreground/30 bg-muted/20 text-foreground"
                    : "border-border bg-transparent text-foreground hover:bg-surface"
                }`}
              >
                {type === "coach" ? "Coach / bus" : type.charAt(0).toUpperCase() + type.slice(1)}
              </button>
            ))}
          </div>
        </div>

        {/* Travel scope */}
        <div>
          <div className="text-xs font-semibold mb-2">Travel scope</div>
          <div className="space-y-2">
            {(["domestic", "international"] as const).map((s) => (
              <button
                key={s}
                onClick={() => setScope(s)}
                className={`w-full rounded-lg border p-2 text-sm font-medium text-left transition-all ${
                  scope === s
                    ? "border-foreground/30 bg-muted/20 text-foreground"
                    : "border-border bg-transparent text-foreground hover:bg-surface"
                }`}
              >
                {s.charAt(0).toUpperCase() + s.slice(1)}
              </button>
            ))}
          </div>
        </div>

        {/* Booking approach */}
        <div>
          <div className="text-xs font-semibold mb-2">Booking approach</div>
          <div className="space-y-2">
            <button
              onClick={() => setBookingApproachState("self")}
              className={`w-full rounded-lg border p-2 text-sm font-medium text-left transition-all ${
                bookingApproachState === "self"
                  ? "border-foreground/30 bg-muted/20 text-foreground"
                  : "border-border bg-transparent text-foreground hover:bg-surface"
              }`}
            >
              Everyone books their own
            </button>
            <button
              onClick={() => setBookingApproachState("centralised")}
              className={`w-full rounded-lg border p-2 text-sm font-medium text-left transition-all ${
                bookingApproachState === "centralised"
                  ? "border-foreground/30 bg-muted/20 text-foreground"
                  : "border-border bg-transparent text-foreground hover:bg-surface"
              }`}
            >
              Centralised booking
            </button>
          </div>
        </div>

        {/* Booked via (only if centralised) */}
        {bookingApproachState === "centralised" && (
          <div>
            <div className="text-xs font-semibold mb-1">Booked via (optional)</div>
            <input
              type="text"
              value={providerName}
              onChange={(e) => setProviderName(e.target.value)}
              placeholder="Travel agent / concierge name"
              className="w-full rounded-lg border border-border bg-surface px-3 py-2 text-sm text-foreground outline-none focus:border-foreground/30"
            />
          </div>
        )}

        {/* Note */}
        <div>
          <div className="text-xs font-semibold mb-1">Note (optional)</div>
          <textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Any additional travel information"
            className="w-full rounded-lg border border-border bg-surface px-3 py-2 text-sm text-foreground outline-none focus:border-foreground/30 resize-none"
            rows={3}
          />
        </div>

        {/* Actions */}
        <div className="flex gap-2 pt-2">
          <button
            onClick={() => {
              setEditing(false);
              // Reset to original values from trip
              setTravelType(trip.travelType || null);
              setScope(trip.travelScope || null);
              setBookingApproachState(trip.bookingApproach || null);
              setProviderName(trip.bookingProviderName || "");
              setNote(trip.travelNote || "");
            }}
            className="flex-1 rounded-lg border border-border bg-transparent px-4 py-2 text-sm font-medium text-foreground hover:bg-surface"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={saving}
            className="flex-1 rounded-lg btn-primary px-4 py-2 text-sm font-medium text-white hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {saving ? "Saving..." : "Save"}
          </button>
        </div>

      </div>
    </section>
  );
}

export default function TripDetailPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const searchParams = useSearchParams();
  
  const tripId = useMemo(() => toTripId(params?.id), [params?.id]);
  const isCreatedPhase = searchParams?.get("created") === "1";

  const [trips, setTrips] = useState<Trip[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [currentUserName, setCurrentUserName] = useState<string | null>(null);
  const [activeGroupId, setActiveGroupId] = useState<string | null>(null);
  const [loadingBootstrap, setLoadingBootstrap] = useState(true);
  const [profileHandicap, setProfileHandicap] = useState<number | null>(null);
  const [editingMeetDetails, setEditingMeetDetails] = useState(false);
  const [hideMeetInstrument, setHideMeetInstrument] = useState(false);
  const [editingTripName, setEditingTripName] = useState(false);
  const [tripNameValue, setTripNameValue] = useState<string>("");
  const [showTravelNote, setShowTravelNote] = useState(false);
  const [editingSignupsClose, setEditingSignupsClose] = useState(false);
  const [signupsCloseDateValue, setSignupsCloseDateValue] = useState<string>("");
  
  // v2.1.1: Control Zone C visibility for group trips (A+B only when false)
  const SHOW_ZONE_C_GROUP_TRIPS = false;
  
  // DEV ONLY: v2.32 Preview second Base Camp job for spacing validation
  const PREVIEW_EXTRA_JOB = true;
  const [scoringStarted, setScoringStarted] = useState(false);
  const [showLaterSteps, setShowLaterSteps] = useState(false);
  const [confirmModal, setConfirmModal] = useState<{ isOpen: boolean; title: string; message: string; onConfirm: () => void; onCancel: () => void }>({
    isOpen: false,
    title: "",
    message: "",
    onConfirm: () => {},
    onCancel: () => {},
  });
  const [promptModal, setPromptModal] = useState<{ isOpen: boolean; title: string; message: string; defaultValue: string; placeholder: string; onConfirm: (value: string) => void; onCancel: () => void }>({
    isOpen: false,
    title: "",
    message: "",
    defaultValue: "",
    placeholder: "",
    onConfirm: () => {},
    onCancel: () => {},
  });

  const supabase = useMemo(() => {
    return createBrowserClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
    );
  }, []);

  // Bootstrap: fetch user, member profile, and group data in one call
  useEffect(() => {
    async function loadBootstrap() {
      const start = perfMark("bootstrap");
      try {
        const res = await fetch("/api/me/bootstrap", { credentials: "include" });
        if (!res.ok) {
          if (res.status === 401) {
            // Not authenticated - redirect handled by layout
            perfMeasure("bootstrap", start);
            setLoadingBootstrap(false);
            return;
          }
          throw new Error("Failed to load bootstrap data");
        }

        const bootstrap = await res.json();
        
        setCurrentUserId(bootstrap.userId);
        setCurrentUserName(bootstrap.member?.display_name || bootstrap.member?.full_name || null);
        setActiveGroupId(bootstrap.activeGroupId);
        
        const duration = perfMeasure("bootstrap", start);
        perfLog("bootstrap: success", {
          durationMs: duration.toFixed(2),
          activeGroupId: bootstrap.activeGroupId,
          membershipCount: bootstrap.approvedGroups?.length || 0,
        });
      } catch (error) {
        perfMeasure("bootstrap", start);
        perfLog("bootstrap: error", { error: error instanceof Error ? error.message : String(error) });
      } finally {
        setLoadingBootstrap(false);
      }
    }
    loadBootstrap();
  }, []);

  // Load trips and courses once activeGroupId is known
  useEffect(() => {
    if (!activeGroupId) return;

    async function loadData() {
      if (!activeGroupId) return;
      try {
        const [tripsData, coursesData] = await Promise.all([
          loadTrips(activeGroupId, false),
          loadCourses()
        ]);
        setTrips(tripsData);
        setCourses(coursesData);
      } catch (error) {
        perfLog("loadData: error", { error: error instanceof Error ? error.message : String(error) });
      }
    }
    loadData();
  }, [activeGroupId]);

  // Load profile handicap (single source of truth)
  useEffect(() => {
    if (!currentUserId) {
      setProfileHandicap(null);
      return;
    }

    async function loadProfileHandicap() {
      try {
        const { data: memberData } = await supabase
          .from("members")
          .select("declared_handicap")
          .eq("id", currentUserId)
          .maybeSingle();

        if (memberData && typeof memberData.declared_handicap === "number") {
          setProfileHandicap(memberData.declared_handicap);
        } else {
          setProfileHandicap(null);
        }
      } catch (error) {
        console.error("Failed to load profile handicap:", error);
        setProfileHandicap(null);
      }
    }

    loadProfileHandicap();
  }, [currentUserId, supabase]);

  // Check if scoring has started for this trip
  useEffect(() => {
    if (!tripId || !activeGroupId) {
      setScoringStarted(false);
      return;
    }

    async function checkScoringStarted() {
      try {
        // First, get the trip's uuid from the trips table using legacy_id
        const { data: tripData, error: tripError } = await supabase
          .from("trips")
          .select("id")
          .eq("legacy_id", tripId)
          .maybeSingle();

        if (tripError || !tripData) {
          setScoringStarted(false);
          return;
        }

        // Then check if any scores exist for this trip
        const { data: scoreData, error: scoreError } = await supabase
          .from("gameday_scores")
          .select("id")
          .eq("trip_id", tripData.id)
          .limit(1)
          .maybeSingle();

        if (scoreError && scoreError.code !== "PGRST116") { // PGRST116 is "not found", which is fine
          console.error("Failed to check scoring status:", scoreError);
          setScoringStarted(false);
          return;
        }

        setScoringStarted(Boolean(scoreData));
      } catch (error) {
        console.error("Failed to check scoring status:", error);
        setScoringStarted(false);
      }
    }

    checkScoringStarted();
  }, [tripId, activeGroupId, supabase]);

  const trip = useMemo(() => {
    if (!tripId) return undefined;
    return trips.find((t) => t.id === tripId);
  }, [trips, tripId]);

  // Phase inference for group trips (must be before early returns)
  type TripPhase = "created" | "forming" | "locked" | "playing_today" | "in_progress" | "afterglow";
  const currentPhase = useMemo<TripPhase>(() => {
    if (!trip) return "forming";
    
    // 1) Afterglow - trip is completed
    if (trip.result || trip.coordinationStatus === "completed") {
      return "afterglow";
    }
    
    // 2) In progress (GameDay) - scoring has started
    if (scoringStarted) {
      return "in_progress";
    }
    
    // 3) Playing today - trip date is today
    const today = new Date().toISOString().slice(0, 10);
    const isToday = trip.date === today;
    if (isToday && !scoringStarted) {
      return "playing_today";
    }
    
    // 4) Locked - trip status is closed/locked
    if (trip.status === "closed" && !isToday && !scoringStarted) {
      return "locked";
    }
    
    // 5) Created - only if ?created=1 query param
    if (isCreatedPhase) {
      return "created";
    }
    
    // 6) Forming - default for open signups / before trip day
    return "forming";
  }, [trip, scoringStarted, isCreatedPhase]);

  // Base Camp phase calculations (for group trips only)
  const phaseOrder: TripPhase[] = ["created", "forming", "locked", "playing_today", "in_progress", "afterglow"];
  const currentPhaseIndex = useMemo(() => phaseOrder.indexOf(currentPhase), [currentPhase]);
  const nextPhase = useMemo<TripPhase | null>(
    () => currentPhaseIndex < phaseOrder.length - 1 ? phaseOrder[currentPhaseIndex + 1] : null,
    [currentPhaseIndex]
  );
  const phaseLabels: Record<TripPhase, string> = {
    created: "Created",
    forming: "Forming",
    locked: "Locked",
    playing_today: "Playing today",
    in_progress: "In progress",
    afterglow: "Afterglow",
  };

  // Base Camp Instrument Registry types and computation (must be before early returns)
  type BaseCampBoundary =
    | "before_signups_open"
    | "before_signups_close"
    | "before_gameday"
    | "any";

  type BaseCampInstrument = {
    id: "trip_name" | "meet_details" | "travel_outline" | "preview_travel" | "signups_close"; // preview_travel is DEV ONLY
    boundary: BaseCampBoundary;
    label: string;
    isRelevant: boolean;
    isDone: boolean;
    chromeLine?: string | null;
    renderInline?: (() => JSX.Element) | null;
    renderLink?: (() => JSX.Element) | null;
    pastLine?: string | null;
  };

  // Convert simple derived values from useMemo to plain const (reduce hooks)
  const isHostedRoundTrip = trip ? isHostedRound(trip) : false;
  const isGroupTripPage = trip ? isGroupTrip(trip) : false;

  // Compute canonical signals once (for group trips) - must be before early returns
  const signals = useMemo(() => {
    if (!trip || !isGroupTripPage) return null;

    // Scheduled: open trip, but signups only open within 30 days of trip date
    const tripDateUtc = trip ? new Date(trip.date + "T00:00:00Z").getTime() : NaN;
    const signupOpenUtc = Number.isFinite(tripDateUtc)
      ? tripDateUtc - 30 * 24 * 60 * 60 * 1000
      : NaN;
    const signupOpenDateYmd = Number.isFinite(signupOpenUtc)
      ? new Date(signupOpenUtc).toISOString().slice(0, 10)
      : null;

    // Scheduled state
    const isScheduledValue = !!trip &&
      trip.status === "open" &&
      !trip.result &&
      Number.isFinite(signupOpenUtc) &&
      Date.now() < signupOpenUtc;

    // Signups state
    const signupsOpenNow = trip.status === "open" && !isScheduledValue;

    // Trip date state
    const today = new Date().toISOString().slice(0, 10);
    const isTripToday = trip.date === today;

    // Meet details state
    const meetTimeVal = (trip.decisionLogistics?.meetTime || trip.logistics?.meetTime || "").trim();
    const meetingPointVal = (trip.decisionLogistics?.meetingPoint || trip.logistics?.meetingPoint || "").trim();
    const hasMeetDetailsValue = Boolean(meetTimeVal || meetingPointVal);
    const meetSummaryLine = hasMeetDetailsValue ? (() => {
      const parts: string[] = [];
      if (meetTimeVal) parts.push(meetTimeVal);
      if (meetingPointVal) parts.push(meetingPointVal);
      return `Meet: ${parts.join(" · ")}`;
    })() : null;

    // Travel details state
    const travelInvolvedValue = trip.travelInvolved === true;
    const hasTravelDetailsValue = travelInvolvedValue && Boolean(
      trip.travelType || trip.travelScope || trip.bookingApproach || trip.bookingProviderName || trip.travelNote
    );
    const travelSummaryLine = hasTravelDetailsValue ? (() => {
      const parts: string[] = [];
      if (trip.travelType) {
        parts.push(trip.travelType === "coach" ? "Coach / bus" : trip.travelType.charAt(0).toUpperCase() + trip.travelType.slice(1));
      }
      if (trip.travelScope) {
        parts.push(trip.travelScope.charAt(0).toUpperCase() + trip.travelScope.slice(1));
      }
      if (trip.bookingApproach === "centralised" && trip.bookingProviderName) {
        parts.push(`Centralised (${trip.bookingProviderName})`);
      } else if (trip.bookingApproach === "self") {
        parts.push("Self-booked");
      } else if (trip.bookingApproach === "centralised") {
        parts.push("Centralised");
      }
      return `Travel: ${parts.join(" · ")}`;
    })() : null;

    // Compute signups close date: default to trip.date - 4 days, or use persisted value if available
    // TODO: Persist signups close date in trips (check for existing field: cutoffAt, signupCloseDate, etc.)
    const defaultSignupsCloseDate = trip?.date ? (() => {
      const tripDate = new Date(trip.date + "T00:00:00");
      tripDate.setDate(tripDate.getDate() - 4);
      return tripDate.toISOString().slice(0, 10);
    })() : null;
    
    // Check for persisted close date (using cutoffAt if available, or computed default)
    const persistedCloseDate = trip?.cutoffAt ? new Date(trip.cutoffAt).toISOString().slice(0, 10) : null;
    const signupsCloseDateYmd = persistedCloseDate || defaultSignupsCloseDate;
    
    // Format close date for display: "Fri 13 Jan"
    const formatCloseDate = (ymd: string | null): string | null => {
      if (!ymd) return null;
      const dateObj = new Date(ymd + "T00:00:00");
      const day = dateObj.toLocaleDateString("en-GB", { weekday: "short" });
      const dayNum = dateObj.getDate();
      const mon = dateObj.toLocaleDateString("en-GB", { month: "short" });
      return `${day} ${dayNum} ${mon}`;
    };
    const signupsCloseDateFormatted = formatCloseDate(signupsCloseDateYmd);

    return {
      isScheduled: isScheduledValue,
      signupsOpenNow,
      signupOpenDateYmd,
      isTripToday,
      hasMeetDetails: hasMeetDetailsValue,
      meetTimeVal,
      meetingPointVal,
      meetSummaryLine,
      travelInvolved: travelInvolvedValue,
      hasTravelDetails: hasTravelDetailsValue,
      travelSummaryLine,
      signupsCloseDateYmd,
      signupsCloseDateFormatted,
    };
  }, [trip, isGroupTripPage]);

  // Build instrument registry (group trips only) - must be before early returns
  const instruments: BaseCampInstrument[] = useMemo(() => {
    if (!signals) return [];

    const canEdit = trip?.createdByMemberId === currentUserId;
    const today = new Date().toISOString().slice(0, 10);
    
    // Use signups close date from signals (computed in signals useMemo)
    const signupsCloseDateYmd = signals.signupsCloseDateYmd;
    const signupsCloseDateFormatted = signals.signupsCloseDateFormatted;

    // 1) trip_name instrument
    const tripNameInstrument: BaseCampInstrument = {
      id: "trip_name",
      boundary: "any",
      label: "Trip name confirmed",
      isRelevant: true,
      isDone: true,
      chromeLine: null,
      renderInline: null,
      renderLink: null,
    };

    // 2) meet_details instrument
    const meetDetailsBoundary: BaseCampBoundary =
      signals.isScheduled && !signals.signupsOpenNow
        ? "before_signups_open"
        : signals.signupsOpenNow && signupsCloseDateYmd && trip?.status !== "closed"
          ? "before_signups_close"
          : "before_gameday";

    const meetDetailsInstrument: BaseCampInstrument = {
      id: "meet_details",
      boundary: meetDetailsBoundary,
      label: "Set meet time and place",
      isRelevant: true,
      isDone: signals.hasMeetDetails,
      chromeLine: signals.meetSummaryLine || null,
      pastLine: signals.hasMeetDetails ? "Meet details set" : null,
      renderInline: !signals.hasMeetDetails && !hideMeetInstrument && canEdit ? (() => {
        return (
          <div className="mt-3 rounded-lg border border-border bg-surface p-4 space-y-3">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-sm font-medium text-foreground">Meet details</div>
                <p className="mt-1 text-xs text-muted">Set the time and place so everyone's ready.</p>
              </div>
              <button
                type="button"
                onClick={() => setHideMeetInstrument(true)}
                className="text-xs text-muted hover:text-foreground underline"
              >
                Not now
              </button>
            </div>
            <MeetDetailsEditor
              trip={trip!}
              currentUserId={currentUserId}
              supabase={supabase}
              activeGroupId={activeGroupId}
              onUpdate={(updatedTrip) => {
                setTrips((prev) => prev.map((t) => (t.id === trip!.id ? updatedTrip : t)));
                setEditingMeetDetails(false);
                setHideMeetInstrument(false);
              }}
            />
          </div>
        );
      }) : null,
      renderLink: !signals.hasMeetDetails && hideMeetInstrument && canEdit ? (() => {
        return (
          <button
            type="button"
            onClick={() => setHideMeetInstrument(false)}
            className="ml-2 text-xs text-muted hover:text-foreground underline"
          >
            Add meet details
          </button>
        );
      }) : null,
    };

    // 3) travel_outline instrument
    // Note: To preview spacing with two jobs, ensure trip.travelInvolved === true and travel details are incomplete
    const travelBoundary: BaseCampBoundary =
      signals.isScheduled && !signals.signupsOpenNow
        ? "before_signups_open"
        : "before_gameday";

    const travelInstrument: BaseCampInstrument = {
      id: "travel_outline",
      boundary: travelBoundary,
      label: "Outline travel",
      isRelevant: signals.travelInvolved === true,
      isDone: signals.hasTravelDetails,
      chromeLine: signals.travelSummaryLine || null,
      renderInline: null,
      // v2.31: Since Zone C is omitted, renderLink is non-clickable (spacing validation only)
      renderLink: signals.travelInvolved && !signals.hasTravelDetails ? (() => {
        return (
          <span className="ml-2 text-xs text-muted opacity-50">
            (Coming soon)
          </span>
        );
      }) : null,
    };

    // 4) signups_close instrument (v2.34)
    const signupsCloseInstrument: BaseCampInstrument = {
      id: "signups_close",
      boundary: "before_signups_close",
      label: signupsCloseDateFormatted ? `Sign-ups close on ${signupsCloseDateFormatted}` : "Sign-ups close date",
      isRelevant: signals.signupsOpenNow === true,
      isDone: true, // Always done (we always have a default), but still configurable
      chromeLine: null, // Do not compile to chrome for now
      pastLine: null,
      renderInline: editingSignupsClose && canEdit ? (() => {
        return (
          <div className="mt-3 rounded-lg border border-border bg-surface p-4 space-y-3">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-sm font-medium text-foreground">Sign-ups close date</div>
                <p className="mt-1 text-xs text-muted">When should sign-ups close?</p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setEditingSignupsClose(false);
                  setSignupsCloseDateValue(signupsCloseDateYmd || "");
                }}
                className="text-xs text-muted hover:text-foreground underline"
              >
                Cancel
              </button>
            </div>
            <div>
              <input
                type="date"
                value={signupsCloseDateValue || signupsCloseDateYmd || ""}
                onChange={(e) => setSignupsCloseDateValue(e.target.value)}
                className="w-full rounded-xl border border-border px-3 py-2 text-sm outline-none focus:border-foreground/30"
              />
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={async () => {
                  if (!currentUserId || !activeGroupId || !trip) return;
                  try {
                    // Try to persist to cutoffAt field if it exists in schema
                    const cutoffAtValue = signupsCloseDateValue ? new Date(signupsCloseDateValue + "T00:00:00").toISOString() : null;
                    
                    // Attempt to persist to database (cutoffAt field)
                    const { error } = await supabase
                      .from("trips")
                      .update({
                        cutoff_at: cutoffAtValue,
                      })
                      .eq("legacy_id", trip.id);

                    if (error) {
                      // If field doesn't exist, just update local state
                      console.warn("Could not persist signups close date (field may not exist):", error);
                    }

                    // Update local state regardless
                    const freshTrips = await loadTrips(activeGroupId, true);
                    const updatedTrip = freshTrips.find(t => t.id === trip.id);
                    
                    if (updatedTrip) {
                      setTrips((prev) => prev.map((t) => (t.id === trip.id ? updatedTrip : t)));
                    } else {
                      // Fallback: update local state only
                      const fallbackTrip = {
                        ...trip,
                        cutoffAt: cutoffAtValue,
                      };
                      setTrips((prev) => prev.map((t) => (t.id === trip.id ? fallbackTrip : t)));
                    }
                    
                    setEditingSignupsClose(false);
                  } catch (error) {
                    console.error("Failed to save signups close date:", error);
                    // Still update local state on error
                    const fallbackTrip = {
                      ...trip,
                      cutoffAt: signupsCloseDateValue ? new Date(signupsCloseDateValue + "T00:00:00").toISOString() : null,
                    };
                    setTrips((prev) => prev.map((t) => (t.id === trip.id ? fallbackTrip : t)));
                    setEditingSignupsClose(false);
                  }
                }}
                className="rounded-xl btn-primary px-4 py-2 text-sm font-medium text-white hover:opacity-90"
              >
                Save
              </button>
            </div>
          </div>
        );
      }) : null,
      renderLink: !editingSignupsClose && canEdit && signals.signupsOpenNow ? (() => {
        return (
          <button
            type="button"
            onClick={() => {
              setEditingSignupsClose(true);
              setSignupsCloseDateValue(signupsCloseDateYmd || "");
            }}
            className="ml-auto text-xs text-muted hover:text-foreground underline"
          >
            Edit
          </button>
        );
      }) : null,
    };

    // Build base instruments array (ordered: meet_details, signups_close, travel_outline)
    const baseInstruments: BaseCampInstrument[] = [tripNameInstrument, meetDetailsInstrument, signupsCloseInstrument, travelInstrument];
    
    // DEV ONLY: v2.32 Add preview instrument for spacing validation (group trips only)
    if (PREVIEW_EXTRA_JOB && isGroupTripPage) {
      const previewInstrument: BaseCampInstrument = {
        id: "preview_travel",
        boundary: meetDetailsBoundary, // Same boundary as meet_details so they stack
        label: "Outline travel plan (so everyone can book)",
        isRelevant: true, // Always relevant when flag is true
        isDone: false, // Always outstanding for preview
        chromeLine: null, // Never compiles to chrome
        renderInline: null, // No inline editor
        renderLink: null, // No click handler
        pastLine: null, // No past line
      };
      baseInstruments.push(previewInstrument);
    }
    
    return baseInstruments;
  }, [signals, trip, currentUserId, hideMeetInstrument, supabase, activeGroupId, showTravelNote, isGroupTripPage, editingSignupsClose, signupsCloseDateValue]);

  // Sync hideMeetInstrument when meet details are added
  useEffect(() => {
    if (!signals || !signals.hasMeetDetails) return;
    setHideMeetInstrument(false);
  }, [signals?.hasMeetDetails]);

  // Initialize signups close date value from trip
  useEffect(() => {
    if (!trip) return;
    const defaultCloseDate = trip.date ? (() => {
      const tripDate = new Date(trip.date + "T00:00:00");
      tripDate.setDate(tripDate.getDate() - 4);
      return tripDate.toISOString().slice(0, 10);
    })() : null;
    const persistedCloseDate = trip.cutoffAt ? new Date(trip.cutoffAt).toISOString().slice(0, 10) : null;
    const closeDateYmd = persistedCloseDate || defaultCloseDate;
    if (!editingSignupsClose && signupsCloseDateValue !== closeDateYmd) {
      setSignupsCloseDateValue(closeDateYmd || "");
    }
  }, [trip?.date, trip?.cutoffAt, editingSignupsClose]);

  // Scroll to meet-details anchor if hash is present
  useEffect(() => {
    if (typeof window !== 'undefined' && window.location.hash === '#meet-details') {
      // Small delay to ensure DOM is ready
      setTimeout(() => {
        const element = document.getElementById('meet-details');
        if (element) {
          element.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }, 100);
    }
  }, [trip]);

  // Sync meet details edit state when trip changes
  useEffect(() => {
    if (!trip) return;
    const meetTimeValue =
      (trip.decisionLogistics?.meetTime || trip.logistics?.meetTime || "").trim();
    const meetingPointValue =
      (trip.decisionLogistics?.meetingPoint || trip.logistics?.meetingPoint || "").trim();
    const noteValue =
      (trip.decisionLogistics?.notes || trip.logistics?.notes || "").trim();
    const hasMeetDetails = isHostedRound(trip)
      ? Boolean(meetTimeValue || meetingPointValue || noteValue)
      : Boolean(meetTimeValue || meetingPointValue);
    // If details become available (e.g. just saved), collapse to read-only.
    if (hasMeetDetails) setEditingMeetDetails(false);
    // If details are cleared somehow, go back to edit mode.
    if (!hasMeetDetails) setEditingMeetDetails(true);
  }, [trip]);

  // Sync trip name edit state when trip changes
  useEffect(() => {
    if (!trip || editingTripName) return;
    setTripNameValue(trip.tripName || trip.name || "");
  }, [trip, editingTripName]);

  // Scheduled: open trip, but signups only open within 30 days of trip date (computed in signals for group trips, duplicated here for hosted rounds)
  const tripDateUtc = trip ? new Date(trip.date + "T00:00:00Z").getTime() : NaN;
  const signupOpenUtc = Number.isFinite(tripDateUtc)
    ? tripDateUtc - 30 * 24 * 60 * 60 * 1000
    : NaN;
  const signupOpenDateYmd = Number.isFinite(signupOpenUtc)
    ? new Date(signupOpenUtc).toISOString().slice(0, 10)
    : null;
  const isScheduled =
    !!trip &&
    trip.status === "open" &&
    !trip.result &&
    Number.isFinite(signupOpenUtc) &&
    Date.now() < signupOpenUtc;

  const courseText = useMemo(() => {
    if (!trip) return null;
    return getTripCourseText(trip, courses);
  }, [trip, courses]);

  const course = useMemo(() => {
    if (!trip?.courseId) return undefined;
    return courses.find((c) => c.id === trip.courseId);
  }, [trip, courses]);

  const myEntry = useMemo(() => {
    if (!trip) return undefined;
    // Prefer matching by memberId (supabase user id); fall back to name match if needed
    if (currentUserId) {
      const byId = trip.attendees.find((a) => a.memberId && a.memberId === currentUserId);
      if (byId) return byId;
    }
    if (currentUserName) {
      return trip.attendees.find((a) => a.name === currentUserName);
    }
    return undefined;
  }, [trip, currentUserId, currentUserName]);

  // Debug state tracking removed - use React DevTools instead

  const [hcp, setHcp] = useState<string>("");
  const [attendeeProfilePhotos, setAttendeeProfilePhotos] = useState<
    Array<{ memberId: string; name: string; photoUrl: string | null }>
  >([]);
  const [hostedRoundAttendees, setHostedRoundAttendees] = useState<
    Array<{
      memberId: string | null;
      name: string;
      photoUrl: string | null;
      handicap: number | null;
      handicapForTrip: number | null | undefined;
      isWaitlist: boolean;
    }>
  >([]);
  const [exportReadinessNotice, setExportReadinessNotice] = useState<{
    show: boolean;
    missingFields: Array<"passport_full_name" | "passport_number" | "passport_nationality" | "passport_date_of_birth" | "passport_expiry_date" | "handicap">;
  } | null>(null);

  // Check export readiness when trip or myEntry changes (for cross_border_agent trips)
  useEffect(() => {
    async function checkReadiness() {
      if (
        trip?.scenarioKey === "cross_border_agent" &&
        myEntry?.status === "confirmed" &&
        currentUserId
      ) {
        try {
          const readiness = await checkMemberExportReadiness(
            currentUserId,
            myEntry.handicapForTrip
          );
          
          if (!readiness.isReady && readiness.missingFields.length > 0) {
            // Only show notice if we don't already have one, or if missing fields changed
            setExportReadinessNotice(prev => {
              if (prev?.show && JSON.stringify(prev.missingFields) === JSON.stringify(readiness.missingFields)) {
                return prev; // Don't update if same
              }
              return {
                show: true,
                missingFields: readiness.missingFields,
              };
            });
          } else if (readiness.isReady) {
            // Hide notice if member becomes ready
            setExportReadinessNotice(null);
          }
        } catch (error) {
          // Silently fail - don't show errors
          console.warn("Failed to check export readiness:", error);
        }
      } else if (trip?.scenarioKey !== "cross_border_agent" || myEntry?.status !== "confirmed") {
        // Hide notice if trip is not cross_border_agent or member is not confirmed
        setExportReadinessNotice(null);
      }
    }
    
    checkReadiness();
  }, [trip?.scenarioKey, trip?.id, myEntry?.status, myEntry?.handicapForTrip, currentUserId]);

  // Compute confirmed and waitlist before early returns (with fallback for null trip)
  const confirmed = useMemo(() => {
    if (!trip) return [];
    return trip.attendees
      .filter((a) => a.status === "confirmed")
      .sort((a, b) => a.joinedAt - b.joinedAt);
  }, [trip]);

  const waitlist = useMemo(() => {
    if (!trip) return [];
    return trip.attendees
      .filter((a) => a.status === "waitlist")
      .sort((a, b) => a.joinedAt - b.joinedAt);
  }, [trip]);

  useEffect(() => {
    if (!myEntry) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setHcp(profileHandicap !== null ? String(profileHandicap) : "");
      return;
    }
    // Prefer profile handicap (single source of truth), fall back to trip-specific snapshot
    const v = profileHandicap !== null ? profileHandicap : (myEntry.handicapForTrip ?? null);
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setHcp(v === null || v === undefined ? "" : String(v));
  }, [myEntry, profileHandicap]);

  // Fetch profile photos for confirmed attendees (up to 4)
  useEffect(() => {
    async function loadAttendeeProfilePhotos() {
      if (!trip || confirmed.length === 0) {
        setAttendeeProfilePhotos([]);
        return;
      }

      // Get up to 4 confirmed attendees with memberIds
      const attendeesWithMemberIds = confirmed
        .filter((a) => a.memberId)
        .slice(0, 4);

      if (attendeesWithMemberIds.length === 0) {
        setAttendeeProfilePhotos([]);
        return;
      }

      try {
        const { data: memberData } = await supabase
          .from("members")
          .select("id,profile_photo_path,display_name,full_name")
          .in(
            "id",
            attendeesWithMemberIds.map((a) => a.memberId!)
          );

        if (memberData) {
          const photos = attendeesWithMemberIds.map((attendee) => {
            const member = memberData.find((m) => m.id === attendee.memberId);
            const photoPath = member?.profile_photo_path;
            const photoUrl = photoPath
              ? `${process.env.NEXT_PUBLIC_SUPABASE_URL}/storage/v1/object/public/${photoPath}`
              : null;
            return {
              memberId: attendee.memberId!,
              name: attendee.name,
              photoUrl,
            };
          });
          setAttendeeProfilePhotos(photos);
        }
      } catch (error) {
        perfLog("loadAttendeeProfilePhotos: error", { error: error instanceof Error ? error.message : String(error) });
        setAttendeeProfilePhotos([]);
      }
    }

    loadAttendeeProfilePhotos();
  }, [trip, confirmed, supabase]);

  // Fetch full attendee data for hosted rounds (avatar + handicap)
  useEffect(() => {
    async function loadHostedRoundAttendees() {
      if (!trip || !isHostedRound(trip)) {
        setHostedRoundAttendees([]);
        return;
      }

      const allAttendees = [...confirmed, ...waitlist];
      if (allAttendees.length === 0) {
        setHostedRoundAttendees([]);
        return;
      }

      // Get all attendees with memberIds
      const attendeesWithMemberIds = allAttendees.filter((a) => a.memberId);

      if (attendeesWithMemberIds.length === 0) {
        // If no memberIds, still show attendees with names and handicapForTrip
        setHostedRoundAttendees(
          allAttendees.map((a) => ({
            memberId: a.memberId || null,
            name: a.name,
            photoUrl: null,
            handicap: null,
            handicapForTrip: a.handicapForTrip,
            isWaitlist: a.status === "waitlist",
          }))
        );
        return;
      }

      try {
        const { data: memberData } = await supabase
          .from("members")
          .select("id,profile_photo_path,display_name,full_name,declared_handicap")
          .in(
            "id",
            attendeesWithMemberIds.map((a) => a.memberId!)
          );

        if (memberData) {
          const attendees = allAttendees.map((attendee) => {
            const member = memberData.find((m) => m.id === attendee.memberId);
            const photoPath = member?.profile_photo_path;
            const photoUrl = photoPath
              ? `${process.env.NEXT_PUBLIC_SUPABASE_URL}/storage/v1/object/public/${photoPath}`
              : null;
            return {
              memberId: attendee.memberId || null,
              name: attendee.name,
              photoUrl,
              handicap: member?.declared_handicap ?? null,
              handicapForTrip: attendee.handicapForTrip,
              isWaitlist: attendee.status === "waitlist",
            };
          });
          setHostedRoundAttendees(attendees);
        }
      } catch (error) {
        perfLog("loadHostedRoundAttendees: error", { error: error instanceof Error ? error.message : String(error) });
        // Fallback to basic data
        setHostedRoundAttendees(
          allAttendees.map((a) => ({
            memberId: a.memberId || null,
            name: a.name,
            photoUrl: null,
            handicap: null,
            handicapForTrip: a.handicapForTrip,
            isWaitlist: a.status === "waitlist",
          }))
        );
      }
    }

    loadHostedRoundAttendees();
  }, [trip, confirmed, waitlist, supabase]);

  if (!tripId) {
    return (
      <div className="rounded-xl border bg-surface p-5 shadow-sm">
        <div className="text-lg font-semibold text-foreground">Invalid trip</div>
        <Link href="/trips" className="mt-3 inline-block text-sm text-foreground hover:text-foreground">
          ← Back to Trips
        </Link>
      </div>
    );
  }

  if (!trip) {
    return (
      <div className="rounded-xl border bg-surface p-5 shadow-sm">
        <div className="text-lg font-semibold text-foreground">Trip not found</div>
        <div className="mt-2 text-sm text-muted">This trip id doesn't exist.</div>
        <Link href="/trips" className="mt-3 inline-block text-sm text-foreground hover:text-foreground">
          ← Back to Trips
        </Link>
      </div>
    );
  }

  // From here down, trip is guaranteed
  const tripIdSafe = trip.id;
  const locked = isTripLocked(trip);
  const joinDisabled = locked || isScheduled || trip.status === "cancelled";

  // Meet details state: derive current values and edit mode
  const meetTimeValue =
    (trip.decisionLogistics?.meetTime || trip.logistics?.meetTime || "").trim();

  const meetingPointValue =
    (trip.decisionLogistics?.meetingPoint || trip.logistics?.meetingPoint || "").trim();
  
  const noteValue =
    (trip.decisionLogistics?.notes || trip.logistics?.notes || "").trim();

  const hasMeetDetails = isHostedRound(trip)
    ? Boolean(meetTimeValue || meetingPointValue || noteValue)
    : Boolean(meetTimeValue || meetingPointValue);

  async function handleImIn() {
    // Prevent RSVP changes once scoring has started
    if (scoringStarted) return;
    
    // Prevent duplicate joins
    if (myEntry) return;

    if (!currentUserId || !activeGroupId) {
      alert("You must be signed in and have an active group to join a trip.");
      return;
    }

    try {
      // Use bootstrap data - fetch handicap from members table for trip-specific value
      const { data: memberData } = await supabase
        .from("members")
        .select("full_name,display_name,nationality,declared_handicap")
        .eq("id", currentUserId)
        .maybeSingle();

      const existingHandicap =
        memberData && typeof memberData.declared_handicap === "number"
          ? memberData.declared_handicap
          : null;

      // Prepare the join action function
      const continueWithHandicap = async (handicapValue: number | null) => {
        try {
          await supabase
            .from("members")
            .update({
              declared_handicap: handicapValue,
              last_seen: new Date().toISOString(),
              full_name: memberData?.full_name ?? null,
              display_name: memberData?.display_name ?? null,
              nationality: memberData?.nationality ?? null,
            })
            .eq("id", currentUserId);

          const updated = await joinTrip(trips, tripIdSafe, handicapValue, activeGroupId);
          setTrips(updated);
          
          // Reload trips to get fresh data
          if (activeGroupId) {
            try {
              const freshTrips = await loadTrips(activeGroupId, true); // Bypass cache
              setTrips(freshTrips);
              
              // Check if this is a cross_border_agent trip and if member needs to complete details
              const joinedTrip = freshTrips.find(t => t.id === tripIdSafe);
              if (joinedTrip?.scenarioKey === "cross_border_agent" && currentUserId) {
                // Find the member's attendee entry
                const myAttendee = joinedTrip.attendees.find(
                  a => a.memberId === currentUserId || a.name === currentUserName
                );
                
                if (myAttendee?.status === "confirmed") {
                  // Check export readiness
                  const readiness = await checkMemberExportReadiness(
                    currentUserId,
                    myAttendee.handicapForTrip
                  );
                  
                  if (!readiness.isReady && readiness.missingFields.length > 0) {
                    // Show notice to complete details
                    setExportReadinessNotice({
                      show: true,
                      missingFields: readiness.missingFields,
                    });
                  }
                }
              }
            } catch (reloadError) {
              perfLog("handleImIn: reload error", { tripId: tripIdSafe, error: reloadError instanceof Error ? reloadError.message : String(reloadError) });
            }
          }
        } catch (error) {
          perfLog("handleImIn: error", { tripId: tripIdSafe, error: error instanceof Error ? error.message : String(error) });
          alert(
            `Failed to join trip: ${error instanceof Error ? error.message : String(error)}`
          );
        }
      };

        if (existingHandicap !== null) {
          // Show confirm modal to ask if they want to edit
          setConfirmModal({
            isOpen: true,
            title: "Edit handicap?",
            message: `Your current handicap is ${existingHandicap}. Do you want to edit it before joining this trip?`,
            onConfirm: () => {
              setConfirmModal({ ...confirmModal, isOpen: false });
              // Show prompt modal for editing handicap
              setPromptModal({
                isOpen: true,
                title: "Enter handicap",
                message: "Enter your handicap for this trip (0–36), or leave blank to keep it the same:",
                defaultValue: String(existingHandicap),
                placeholder: "0–36",
                onConfirm: (input: string) => {
                  setPromptModal({ ...promptModal, isOpen: false });
                  const trimmed = input.trim();
                  let handicapValue: number | null = existingHandicap;
                  if (trimmed === "") {
                    handicapValue = existingHandicap;
                  } else {
                    const parsed = Number(trimmed);
                    if (!Number.isFinite(parsed) || parsed < 0 || parsed > 36) {
                      alert("Handicap must be a number between 0 and 36.");
                      return;
                    }
                    handicapValue = parsed;
                  }
                  void continueWithHandicap(handicapValue);
                },
                onCancel: () => {
                  setPromptModal({ ...promptModal, isOpen: false });
                  // Join with existing handicap even if they cancel the prompt
                  void continueWithHandicap(existingHandicap);
                },
              });
            },
            onCancel: () => {
              setConfirmModal({ ...confirmModal, isOpen: false });
              // Use existing handicap without editing
              void continueWithHandicap(existingHandicap);
            },
          });
        } else {
          // Show prompt modal for new handicap
          setPromptModal({
            isOpen: true,
            title: "Enter handicap",
            message: "Please enter your current handicap (0–36), or leave blank if you are not sure yet:",
            defaultValue: "",
            placeholder: "0–36",
            onConfirm: (input: string) => {
              setPromptModal({ ...promptModal, isOpen: false });
              const trimmed = input.trim();
              let handicapValue: number | null = null;
              if (trimmed !== "") {
                const parsed = Number(trimmed);
                if (!Number.isFinite(parsed) || parsed < 0 || parsed > 36) {
                  alert("Handicap must be a number between 0 and 36.");
                  return;
                }
                handicapValue = parsed;
              }
              void continueWithHandicap(handicapValue);
            },
            onCancel: () => {
              setPromptModal({ ...promptModal, isOpen: false });
              // Join without handicap
              void continueWithHandicap(null);
            },
          });
        }
    } catch (error) {
      perfLog("handleImIn: member update error", { tripId: tripIdSafe, error: error instanceof Error ? error.message : String(error) });
      alert(
        `Failed to join trip: ${error instanceof Error ? error.message : String(error)}`
      );
    }
  }

  async function handleImOut() {
    // Prevent RSVP changes once scoring has started
    if (scoringStarted) return;
    
    setConfirmModal({
      isOpen: true,
      title: "Leave this trip?",
      message: "You'll be removed from the attendee list.",
      onConfirm: async () => {
        setConfirmModal({ ...confirmModal, isOpen: false });
        try {
          const updated = await leaveTrip(trips, tripIdSafe, activeGroupId || undefined);
          setTrips(updated);
          // Reload trips to get fresh data
          if (activeGroupId) {
            try {
              const freshTrips = await loadTrips(activeGroupId, true); // Bypass cache
              setTrips(freshTrips);
            } catch (reloadError) {
              perfLog("handleImOut: reload error", { tripId: tripIdSafe, error: reloadError instanceof Error ? reloadError.message : String(reloadError) });
            }
          }
        } catch (error) {
          perfLog("handleImOut: error", { tripId: tripIdSafe, error: error instanceof Error ? error.message : String(error) });
          alert(`Failed to leave trip: ${error instanceof Error ? error.message : String(error)}`);
        }
      },
      onCancel: () => {
        setConfirmModal({ ...confirmModal, isOpen: false });
      },
    });
  }

  async function saveHandicap() {
    if (!myEntry || !currentUserId) return;

    const trimmed = hcp.trim();
    const parsed = trimmed === "" ? null : Number(trimmed);

    if (trimmed !== "" && !Number.isFinite(parsed)) return;
    if (trimmed !== "" && (parsed! < 0 || parsed! > 36)) {
      alert("Handicap must be a number between 0 and 36.");
      return;
    }

    try {
      // Update profile handicap (single source of truth)
      const { error: profileError } = await supabase
        .from("members")
        .update({
          declared_handicap: parsed,
          last_seen: new Date().toISOString(),
        })
        .eq("id", currentUserId);

      if (profileError) {
        throw profileError;
      }

      // Update local profile handicap state
      setProfileHandicap(parsed);

      // Also update trip-specific snapshot if activeGroupId is available
      if (activeGroupId) {
        try {
          const updated = await setMyHandicapForTrip(trips, tripIdSafe, parsed, activeGroupId);
          setTrips(updated);
          // Reload trips to get fresh data
          try {
            const freshTrips = await loadTrips(activeGroupId, true); // Bypass cache
            setTrips(freshTrips);
          } catch (reloadError) {
            perfLog("saveHandicap: reload error", { tripId: tripIdSafe, error: reloadError instanceof Error ? reloadError.message : String(reloadError) });
          }
        } catch (tripError) {
          // Non-fatal: profile was updated, trip snapshot update failed
          console.warn("Failed to update trip snapshot:", tripError);
        }
      }
    } catch (error) {
      perfLog("saveHandicap: error", { tripId: tripIdSafe, error: error instanceof Error ? error.message : String(error) });
      alert(`Failed to save handicap: ${error instanceof Error ? error.message : String(error)}`);
    }
  }


  // Parse course name and tee from courseText.title (format: "Course Name — Tee Label" or just "Course Name")
  const courseName = courseText?.title?.includes(" — ")
    ? courseText.title.split(" — ")[0]
    : courseText?.title !== "Course TBD"
    ? courseText?.title
    : null;
  const teeLabel = courseText?.title?.includes(" — ")
    ? courseText.title.split(" — ")[1]
    : null;

  // Extract metrics from courseText.detail (format: "6000m · Par 72 · Slope 120")
  const metricsParts = courseText?.detail?.split(" · ") || [];
  const meters = metricsParts.find((p) => p.endsWith("m")) || null;
  const par = metricsParts.find((p) => p.startsWith("Par "))?.replace("Par ", "") || null;
  const slope = metricsParts.find((p) => p.startsWith("Slope "))?.replace("Slope ", "") || null;

  // Build golf details secondary line: "Blue Tees · Stableford · 6000m · Par 72 · Slope 120"
  const golfDetailsSecondaryParts: string[] = [];
  if (teeLabel) golfDetailsSecondaryParts.push(teeLabel);
  if (trip.format && !isHostedRound(trip)) golfDetailsSecondaryParts.push(trip.format);
  if (meters) golfDetailsSecondaryParts.push(meters);
  if (par) golfDetailsSecondaryParts.push(`Par ${par}`);
  if (slope) golfDetailsSecondaryParts.push(`Slope ${slope}`);
  const golfDetailsSecondary = golfDetailsSecondaryParts.length > 0
    ? golfDetailsSecondaryParts.join(" · ")
    : null;

  // Extract time from meetTime - prioritize decision logistics, fall back to operational logistics
  const meetTime = (trip.decisionLogistics?.meetTime || trip.logistics?.meetTime)?.trim() || null;
  
  // Get meeting point - prioritize decision logistics, fall back to operational logistics
  const meetingPoint = (trip.decisionLogistics?.meetingPoint || trip.logistics?.meetingPoint)?.trim() || null;

  // Trip state: "Open for sign up" + confirmed count (muted)
  const tripStateText =
    trip.status === "cancelled"
      ? null
      : isScheduled && signupOpenDateYmd
      ? `Signups open ${signupOpenDateYmd}`
      : trip.status === "open" && !isScheduled
      ? "Open for sign up"
      : trip.status === "closed"
      ? "Signups closed"
      : null;

  const confirmedCountValue = trip.attendees.filter((a) => a.status === "confirmed").length;

  // Helper function to get initials from name
  function getInitials(name: string): string {
    const parts = name.trim().split(/\s+/);
    if (parts.length >= 2) {
      return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
    }
    return name.slice(0, 2).toUpperCase();
  }
  
  return (
    <div className={isHostedRoundTrip ? "space-y-3 pb-24" : "space-y-4 pb-24"}>
      <div>
        <button
          type="button"
          onClick={() => {
            if (typeof window !== "undefined" && window.history.length > 1) {
              router.back();
            } else {
              router.push("/trips");
            }
          }}
          className="text-sm text-foreground hover:text-foreground"
        >
          ← Back
        </button>

        {/* Base Camp UI for group trips only */}
        {isGroupTripPage ? (
          <>
            {/* Zone A: Identity (Compiled) */}
            <section aria-label="Trip identity" className="mt-4 space-y-3">
              {/* Trip name */}
              <div>
                {editingTripName && trip.createdByMemberId === currentUserId ? (
                  <div className="space-y-2">
                    <input
                      type="text"
                      value={tripNameValue}
                      onChange={(e) => setTripNameValue(e.target.value)}
                      placeholder="Trip name"
                      className="w-full rounded-lg border border-border bg-surface px-3 py-2 text-xl font-semibold text-foreground outline-none focus:border-foreground/30"
                      autoFocus
                    />
                    <div className="flex items-center gap-2">
                      <button
                        onClick={async () => {
                          if (!currentUserId || !activeGroupId) return;
                          try {
                            const { error } = await supabase
                              .from("trips")
                              .update({
                                trip_name: tripNameValue.trim() || null,
                              })
                              .eq("legacy_id", trip.id);

                            if (error) {
                              throw error;
                            }

                            const freshTrips = await loadTrips(activeGroupId, true);
                            const updatedTrip = freshTrips.find(t => t.id === trip.id);
                            
                            if (updatedTrip) {
                              setTrips((prev) => prev.map((t) => (t.id === trip.id ? updatedTrip : t)));
                            }
                            
                            setEditingTripName(false);
                          } catch (error) {
                            console.error("Failed to save trip name:", error);
                            alert(`Failed to save trip name: ${error instanceof Error ? error.message : String(error)}`);
                          }
                        }}
                        className="rounded-lg btn-primary px-4 py-2 text-sm font-medium text-white hover:opacity-90"
                      >
                        Save
                      </button>
                      <button
                        onClick={() => {
                          setEditingTripName(false);
                          setTripNameValue(trip.tripName || trip.name || "");
                        }}
                        className="rounded-lg border border-border bg-transparent px-4 py-2 text-sm font-medium text-foreground hover:bg-surface"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <div className="text-xl font-semibold text-foreground">
                      {trip.tripName || trip.name || (getGolfNoun(trip) === "trip" ? "Trip" : "Round")}
                    </div>
                    {trip.createdByMemberId === currentUserId && (
                      <button
                        onClick={() => {
                          setEditingTripName(true);
                          setTripNameValue(trip.tripName || trip.name || "");
                        }}
                        className="text-xs text-muted hover:text-foreground underline"
                      >
                        Edit name
                      </button>
                    )}
                  </div>
                )}
              </div>

              {/* Course · location */}
              {(courseName || courseText?.title !== "Course TBD") && (
                <div className="text-base font-medium text-foreground">
                  {courseName || courseText?.title}
                  {course?.location && (
                    <span className="text-muted"> · {course.location}</span>
                  )}
                </div>
              )}

              {/* Date / time */}
              <div className="text-sm text-foreground font-medium">
                {formatTripDateLong(trip.date)}
              </div>

              {/* Compiled details summary (from instruments, read-only) */}
              {instruments
                .filter(instrument => instrument.chromeLine)
                .map((instrument, idx) => (
                  <div key={instrument.id} className="text-xs text-muted">
                    {instrument.chromeLine}
                  </div>
                ))}

              {/* Host indication */}
              {trip.createdByMemberName && (
                <div className="text-sm text-secondary">
                  {trip.createdByMemberId === currentUserId ? "Hosted by you" : `Hosted by ${trip.createdByMemberName.split(" ")[0]}`}
                </div>
              )}
            </section>

            {/* Zone B: Base Camp (Narrative Spine) */}
            <section aria-label="Base Camp" className="mt-6">
              {/* Rail/spine begins here, not above chrome */}
              <div className="grid grid-cols-[28px_1fr] gap-x-3 sm:grid-cols-[40px_1fr]">
              {/* Row 1: What happens next (anchor row) */}
              {/* Left cell: Current phase node + tick (spine starts here, no spine above) */}
              <div className="relative flex items-start">
                <div className="relative z-10 flex items-center pt-[0.375rem]">
                  <div className="h-2.5 w-2.5 rounded-full bg-foreground ring-2 ring-foreground/20 -translate-x-1/2" />
                  <div className="absolute left-0 w-3 h-px bg-border translate-x-1/2" style={{ top: "6px" }} />
                </div>
                <div className="absolute left-0 top-[1.125rem] bottom-0 w-px bg-border" />
              </div>
              {/* Right cell: What happens next sentence (aligned with current phase node) */}
              <div className="pt-[0.375rem]">
                {currentPhase !== "afterglow" && (
                  <div className="text-sm text-muted">
                    {(() => {
                      if ((currentPhase === "created" || currentPhase === "forming") && signals?.isScheduled && signals?.signupOpenDateYmd) {
                        const openDate = new Date(signals.signupOpenDateYmd + "T00:00:00");
                        const day = openDate.toLocaleDateString("en-GB", { weekday: "short" });
                        const date = openDate.getDate();
                        const mon = openDate.toLocaleDateString("en-GB", { month: "short" });
                        return `Sign-ups will open automatically on ${day} ${date} ${mon}.`;
                      }
                      if (currentPhase === "forming" && signals?.signupsOpenNow) {
                        return "Sign-ups are open now.";
                      }
                      if (currentPhase === "locked") {
                        const tripDate = new Date(trip.date + "T00:00:00");
                        const day = tripDate.toLocaleDateString("en-GB", { weekday: "short" });
                        const date = tripDate.getDate();
                        const mon = tripDate.toLocaleDateString("en-GB", { month: "short" });
                        return `Next: Playing today on ${day} ${date} ${mon}.`;
                      }
                      if (currentPhase === "playing_today") {
                        return "GameDay is available today.";
                      }
                      if (currentPhase === "in_progress") {
                        return "Round in progress.";
                      }
                      return null;
                    })()}
                  </div>
                )}
                {currentPhase === "afterglow" && (
                  <div className="text-sm text-muted">
                    Round complete.
                  </div>
                )}
              </div>

              {/* Row 2: Between-anchor instrument lane (readiness) */}
              {/* Left cell: Spine-only (connects Anchor A to Anchor B) */}
              <div className="relative">
                <div className="absolute left-0 top-0 bottom-0 w-px bg-border" />
              </div>
              {/* Right cell: Between-anchor content (instrument slots) - extra horizontal padding for breathing room */}
              <div className="mt-10 pb-10 pl-6">
                {currentPhase !== "in_progress" && currentPhase !== "afterglow" && (() => {
                  // Filter instruments by boundary for current phase (outstanding only)
                  // v2.34: signups_close is always "done" but still shows when signups are open
                  const beforeOpen = instruments.filter(i => i.isRelevant && !i.isDone && i.boundary === "before_signups_open");
                  const beforeClose = instruments.filter(i => 
                    i.isRelevant && 
                    i.boundary === "before_signups_close" &&
                    (!i.isDone || i.id === "signups_close") // Include signups_close even when done
                  );
                  const beforeGameday = instruments.filter(i => i.isRelevant && !i.isDone && i.boundary === "before_gameday");
                  const anyBoundary = instruments.filter(i => i.isRelevant && !i.isDone && i.boundary === "any");

                  // Determine which boundary instruments to show based on phase
                  let activeInstruments: BaseCampInstrument[] = [];
                  if (signals?.isScheduled && !signals?.signupsOpenNow) {
                    activeInstruments = [...beforeOpen, ...beforeGameday, ...anyBoundary];
                  } else if (signals?.signupsOpenNow && trip.status !== "closed") {
                    activeInstruments = [...beforeClose, ...beforeGameday, ...anyBoundary];
                  } else {
                    activeInstruments = [...beforeGameday, ...anyBoundary];
                  }

                  // Guardrail: Only one inline instrument visible at a time (v1 constraint)
                  // Select the first instrument (stable order) that is eligible for inline rendering
                  // Note: renderInline is null when instrument is done, hidden, or user cannot edit
                  // So checking renderInline existence already enforces those conditions
                  // v2.34: signups_close can be edited even when isDone=true (it's always done but configurable)
                  const activeInlineInstrumentId = (() => {
                    // Check instruments in stable order: trip_name, meet_details, travel_outline, signups_close
                    for (const instrument of instruments) {
                      if (
                        instrument.isRelevant &&
                        instrument.renderInline // renderInline is null if hidden/can't edit or not in edit mode
                      ) {
                        // signups_close is always "done" but can still be edited
                        if (instrument.id === "signups_close" || !instrument.isDone) {
                          return instrument.id;
                        }
                      }
                    }
                    return null;
                  })();

                  // Instrument-driven past lines: show muted past lines for completed instruments
                  const pastLineInstruments = instruments.filter(i => 
                    i.isRelevant && i.isDone && i.pastLine
                  );

                  return (
                    <div className="space-y-6">
                        {activeInstruments.slice(0, 3).map((instrument) => (
                          <div key={instrument.id}>
                            {/* Only render inline if this is the selected active inline instrument */}
                            {instrument.renderInline && instrument.id === activeInlineInstrumentId ? (
                              instrument.renderInline()
                            ) : (
                              <div className={`text-sm ${instrument.isDone ? "text-muted opacity-60" : "text-foreground"} flex items-center justify-between gap-2`}>
                                <span>{instrument.label}</span>
                                {instrument.renderLink && instrument.renderLink()}
                              </div>
                            )}
                          </div>
                        ))}
                        {/* Instrument-driven muted past lines (subtle, no checkmarks, no icons) */}
                        {pastLineInstruments.map((instrument) => (
                          <div key={instrument.id} className="text-sm text-muted opacity-60">
                            {instrument.pastLine}
                          </div>
                        ))}
                    </div>
                  );
                })()}
              </div>

              {/* Row 3: Next anchor (next phase) - only render if nextPhase exists */}
              {nextPhase && (
                <>
                  {/* Left cell: Next phase node + tick + spine segment above */}
                  <div className="relative flex items-start">
                    {/* Spine segment above node (connects from between-lane) */}
                    <div className="absolute left-0 top-0 w-px bg-border" style={{ height: "0.5rem" }} />
                    {/* Next phase node (muted/hollow) */}
                    <div className="relative z-10 flex items-center pt-[0.375rem]">
                      <div className="h-2.5 w-2.5 rounded-full border-2 border-border bg-transparent -translate-x-1/2" />
                      <div className="absolute left-0 w-3 h-px bg-border translate-x-1/2" style={{ top: "6px" }} />
                    </div>
                    {/* Spine segment below node (stops at node for now) */}
                    <div className="absolute left-0 top-[1.125rem] bottom-0 w-px bg-border" />
                  </div>
                  {/* Right cell: Next phase "What happens next" sentence */}
                  <div className="pt-[0.375rem]">
                    <div className="text-sm text-muted opacity-60">
                      {(() => {
                        // v2.34: When signups are open, next anchor is signups close date
                        if (signals?.signupsOpenNow && signals?.signupsCloseDateFormatted) {
                          return `Sign-ups close on ${signals.signupsCloseDateFormatted}.`;
                        }
                        // Derive sentence for nextPhase based on existing patterns
                        if (nextPhase === "forming" && signals?.isScheduled && signals?.signupOpenDateYmd) {
                          const openDate = new Date(signals.signupOpenDateYmd + "T00:00:00");
                          const day = openDate.toLocaleDateString("en-GB", { weekday: "short" });
                          const date = openDate.getDate();
                          const mon = openDate.toLocaleDateString("en-GB", { month: "short" });
                          return `Sign-ups will open automatically on ${day} ${date} ${mon}.`;
                        }
                        if (nextPhase === "locked") {
                          const tripDate = new Date(trip.date + "T00:00:00");
                          const day = tripDate.toLocaleDateString("en-GB", { weekday: "short" });
                          const date = tripDate.getDate();
                          const mon = tripDate.toLocaleDateString("en-GB", { month: "short" });
                          return `Next: Playing today on ${day} ${date} ${mon}.`;
                        }
                        if (nextPhase === "playing_today") {
                          return "GameDay will be available on the morning of the trip.";
                        }
                        if (nextPhase === "in_progress") {
                          return "Round will begin when GameDay starts.";
                        }
                        if (nextPhase === "afterglow") {
                          return "Round will complete after GameDay finishes.";
                        }
                        // Safe fallback for any unmapped nextPhase
                        return "Next phase will begin automatically.";
                      })()}
                    </div>
                  </div>
                </>
              )}
              </div>
            </section>

            {/* Zone C: Secondary surfaces (below Base Camp) */}
            {/* Large instrument cards and coordination surfaces live here */}
            {/* v2.1.1: All post-BaseCamp content wrapped behind flag */}
            {SHOW_ZONE_C_GROUP_TRIPS && (
              <>
            {/* Meet details instrument - hidden for group trips (replaced by inline instrument) */}
            {!isGroupTripPage && (
          <section id="meet-details" className="mt-6 rounded-xl border bg-surface shadow-sm p-5">
            {(() => {
              const canEditMeetDetails = trip.createdByMemberId === currentUserId;
              
              // Group trip: existing behavior
              if (!canEditMeetDetails) {
                // Non-host view: show read-only or empty state
                if (!hasMeetDetails) {
                  return (
                    <div>
                      <div className="text-sm font-medium text-foreground mb-1">Meet details</div>
                      <p className="text-xs text-muted">Meet details haven't been added yet.</p>
                    </div>
                  );
                }
                // Show read-only details
                return (
                  <div className="space-y-3">
                    <div className="text-sm font-medium text-foreground">Meet details</div>
                    <div>
                      <div className="text-xs text-muted">Meet time</div>
                      <div className="mt-1 text-sm text-foreground">
                        {meetTimeValue ? meetTimeValue : "—"}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-muted">Meeting point</div>
                      <div className="mt-1 text-sm text-foreground">
                        {meetingPointValue ? meetingPointValue : "—"}
                      </div>
                    </div>
                  </div>
                );
              }
              
              // Group trip host view: existing behavior
              return (
                <>
                  <div className="mb-3 flex items-start justify-between gap-3">
                    <div>
                      <div className="text-sm font-medium text-foreground">Meet details</div>
                      <p className="mt-1 text-xs text-muted">
                        {editingMeetDetails ? "Set the time and place so everyone's ready." : "All set."}
                      </p>
                    </div>

                    {hasMeetDetails && (
                      <button
                        type="button"
                        onClick={() => setEditingMeetDetails((v) => !v)}
                        className="rounded-md border border-border bg-transparent px-3 py-1.5 text-xs font-medium text-foreground hover:bg-surface"
                      >
                        {editingMeetDetails ? "Cancel" : "Edit"}
                      </button>
                    )}
                  </div>

                  {editingMeetDetails ? (
                    <MeetDetailsEditor
                      trip={trip}
                      currentUserId={currentUserId}
                      supabase={supabase}
                      activeGroupId={activeGroupId}
                      onUpdate={(updatedTrip) => {
                        setTrips((prev) => prev.map((t) => (t.id === trip.id ? updatedTrip : t)));
                        setEditingMeetDetails(false);
                      }}
                    />
                  ) : (
                    <div className="space-y-3">
                      <div>
                        <div className="text-xs text-muted">Meet time</div>
                        <div className="mt-1 text-sm text-foreground">
                          {meetTimeValue ? meetTimeValue : "—"}
                        </div>
                      </div>
                      <div>
                        <div className="text-xs text-muted">Meeting point</div>
                        <div className="mt-1 text-sm text-foreground">
                          {meetingPointValue ? meetingPointValue : "—"}
                        </div>
                      </div>
                    </div>
                  )}
                </>
              );
            })()}
          </section>
            )}

            {/* Travel instrument (group trips only, when travel involved) */}
            {isGroupTripPage && trip.travelInvolved && (
            <div id="travel-details" className="mt-6">
              <TravelInstrument
                trip={trip}
                currentUserId={currentUserId}
                supabase={supabase}
                activeGroupId={activeGroupId}
                onUpdate={(updatedTrip) => {
                  setTrips((prev) => prev.map((t) => (t.id === trip.id ? updatedTrip : t)));
                }}
              />
            </div>
            )}

            {/* Trip coordination section (organiser area) */}
            <section aria-label="Trip coordination" className="mt-6 space-y-4">
            {/* Next steps (host only) - only shown in Created phase */}
            {trip.createdByMemberId === currentUserId && !isHostedRound(trip) && currentPhase === "created" && (() => {
              const isGroupTrip = trip.tripOrigin === "group" || trip.isPostedToGroup;
              const isHost = trip.createdByMemberId === currentUserId;
              const signupsOpen = trip.status === "open" && !isScheduled;
              const signupsClosed = trip.status === "closed";
              const hasLogistics = Boolean(trip.logistics?.meetingPoint || trip.ferry || trip.logistics?.itineraryDetails || trip.logistics?.ferryDetails || trip.logistics?.notes);
              
              // Build steps array
              const steps: Array<{
                id: string;
                intent: string;
                action: string;
                onClick: () => void;
              }> = [];

              // 1) Meet details - use instrument state
              if (isGroupTrip && !signals?.hasMeetDetails) {
                steps.push({
                  id: "meet_details",
                  intent: "Set the meetup time and place.",
                  action: "Add meet details",
                  onClick: () => {
                    setHideMeetInstrument(false);
                  },
                });
              }

              // 2) Signups
              if (isGroupTrip && !signupsOpen && !signupsClosed) {
                steps.push({
                  id: "signups",
                  intent: "Let people lock in for the day.",
                  action: "Open signups",
                  onClick: async () => {
                    // TODO: Implement open signups action
                    alert("Open signups functionality to be implemented");
                  },
                });
              }

              // 3) Logistics
              if (isGroupTrip && !hasLogistics) {
                steps.push({
                  id: "logistics",
                  intent: "Share the plan once it's settled.",
                  action: "Publish logistics",
                  onClick: () => {
                    // TODO: Implement publish logistics action
                    alert("Publish logistics functionality to be implemented");
                  },
                });
              }

              // 4) Flights
              if (signupsClosed) {
                steps.push({
                  id: "flights",
                  intent: "Balance flights once signups close.",
                  action: "Set flights",
                  onClick: () => {
                    router.push(`/trips/${trip.id}/flights`);
                  },
                });
              }

              // 5) Exports (only for later, all group trips when appropriate)
              const exportStep = isGroupTrip && (signupsClosed || hasLogistics) ? {
                id: "exports",
                intent: "Export details when needed.",
                action: "Export",
                onClick: () => {
                  // TODO: Implement export action
                  alert("Export functionality to be implemented");
                },
              } : null;

              if (steps.length === 0 && !exportStep) return null;

              const defaultVisible = steps.slice(0, 2);
              const laterSteps = steps.slice(2);
              const allLaterSteps = [...laterSteps, ...(exportStep ? [exportStep] : [])];

              return (
                <section className="rounded-xl border bg-surface p-5 shadow-sm">
                  <div className="mb-4 text-sm font-medium text-foreground">Next steps</div>
                  
                  <div className="space-y-3">
                    {defaultVisible.map((step) => (
                      <div key={step.id} className="flex items-start justify-between gap-3">
                        <p className="text-sm text-muted flex-1">{step.intent}</p>
                        <button
                          onClick={step.onClick}
                          className="rounded-md border border-border bg-transparent px-3 py-1.5 text-xs font-medium text-foreground hover:bg-background shrink-0"
                        >
                          {step.action}
                        </button>
                      </div>
                    ))}

                    {allLaterSteps.length > 0 && (
                      <>
                        {showLaterSteps ? (
                          <>
                            {allLaterSteps.map((step) => (
                              <div key={step.id} className="flex items-start justify-between gap-3">
                                <p className="text-sm text-muted flex-1">{step.intent}</p>
                                <button
                                  onClick={step.onClick}
                                  className="rounded-md border border-border bg-transparent px-3 py-1.5 text-xs font-medium text-foreground hover:bg-background shrink-0"
                                >
                                  {step.action}
                                </button>
                              </div>
                            ))}
                            <button
                              onClick={() => setShowLaterSteps(false)}
                              className="text-xs text-muted hover:text-foreground underline"
                            >
                              Hide
                            </button>
                          </>
                        ) : (
                          <button
                            onClick={() => setShowLaterSteps(true)}
                            className="text-xs text-muted hover:text-foreground underline"
                          >
                            Later
                          </button>
                        )}
                      </>
                    )}
                  </div>
                </section>
              );
            })()}

            {/* Flights (host only, when signups closed) */}
            {trip.status === "closed" && trip.createdByMemberId === currentUserId && (
              <section className="rounded-xl border bg-surface p-5 shadow-sm">
                <div className="mb-3">
                  <div className="text-sm font-medium text-foreground">Flights</div>
                  <p className="mt-1 text-xs text-muted">
                    Balanced automatically. Adjust if you want.
                  </p>
                </div>
                <Link
                  href={`/trips/${trip.id}/flights`}
                  className="inline-block rounded-md border border-border bg-transparent px-4 py-2 text-sm font-medium text-foreground hover:bg-surface"
                >
                  Review flights
                </Link>
              </section>
            )}
            </section>

            {/* Participant area */}
            <div className="mt-6 space-y-4">
            <section className="rounded-xl border bg-surface p-5 shadow-sm">
              <div className="text-sm font-medium text-muted mb-3">RSVP</div>

              {scoringStarted ? (
                <div className="mt-2">
                  <div className="text-sm text-foreground">
                    {myEntry?.status === "confirmed" ? "You're playing today." : "You're marked as not playing."}
                  </div>
                  <div className="mt-1 text-xs text-muted">
                    Scoring has started.
                  </div>
                </div>
              ) : (
                <TripRsvpActions
                  status={myEntry?.status}
                  onJoin={handleImIn}
                  onLeave={handleImOut}
                  joinDisabled={joinDisabled}
                  leaveDisabled={locked}
                  showJoin={signals?.signupsOpenNow ?? (trip.status === "open" && !isScheduled)}
                  showMicrocopy={true}
                  neutralLeaveButton={false}
                />
              )}

              {/* Export readiness notice for cross_border_agent trips */}
              {trip.scenarioKey === "cross_border_agent" && 
               myEntry?.status === "confirmed" && 
               exportReadinessNotice?.show && (
                <div className="mt-4 rounded-lg border border-border bg-background p-3">
                  <div className="text-sm font-medium text-foreground mb-1">
                    This trip requires passport details for the organiser / booking contact.
                  </div>
                  <div className="text-xs text-muted mb-3">
                    Please complete your passport details to enable agent export.
                  </div>
                  <button
                    onClick={() => {
                      // Navigate to Me page with highlight query params for missing fields
                      const highlightParams = exportReadinessNotice.missingFields.join(",");
                      router.push(`/me?highlight=${encodeURIComponent(highlightParams)}`);
                    }}
                    className="rounded-md border border-border bg-transparent px-3 py-1.5 text-xs font-medium text-foreground hover:bg-surface"
                  >
                    Add missing details
                  </button>
                </div>
              )}

              {(signals?.isScheduled ?? isScheduled) && (signals?.signupOpenDateYmd ?? signupOpenDateYmd) && (
                <div className="mt-3 text-sm text-muted">
                  Signups open on <span className="font-semibold">{signals?.signupOpenDateYmd ?? signupOpenDateYmd}</span> (30 days before the trip).
                </div>
              )}
            </section>

            {/* Handicap snapshot */}
            <section className="border-t border-border bg-transparent px-1 pt-4">
              <div className="mb-3 text-sm font-medium text-muted">Handicap snapshot</div>

              {!myEntry ? (
                <div className="text-sm text-muted">RSVP first to save a handicap snapshot for this trip.</div>
              ) : (
                <div className="flex gap-2">
                  <input
                    value={hcp}
                    onChange={(e) => setHcp(e.target.value)}
                    placeholder={profileHandicap !== null ? String(profileHandicap) : "e.g. 12.4"}
                    className="w-full rounded-md border px-3 py-2 text-sm"
                    inputMode="decimal"
                  />
                  <button
                    onClick={saveHandicap}
                    className={`rounded-md px-4 py-2 text-sm font-medium hover:opacity-95 ${
                      // Demote to tertiary if RSVP section has primary Join button
                      trip.status === "open" && !isScheduled && !myEntry
                        ? "border border-border bg-transparent text-foreground hover:bg-surface"
                        : "btn-primary text-white"
                    }`}
                  >
                    Save
                  </button>
                </div>
              )}

              {myEntry && (
                <div className="mt-2 space-y-0.5">
                  <div className="text-xs text-muted">This comes from your profile.</div>
                  <div className="text-xs text-secondary">Saving updates your profile handicap.</div>
                </div>
              )}
            </section>
          </div>
                </>
            )}
          </>
      ) : (
        /* Hosted rounds: keep existing structure unchanged */
        <>
          {/* Trip name */}
          <div className="mt-2">
            <div className="text-xl font-semibold text-foreground">
              {trip.tripName || trip.name || (getGolfNoun(trip) === "trip" ? "Trip" : "Round")}
            </div>
          </div>

          {/* Cancelled info box */}
          {trip.status === "cancelled" && (
            <div className="mt-3 rounded-lg bg-danger-light border border-danger p-3">
              <div className="text-sm text-danger font-semibold">
                This trip has been cancelled.
              </div>
            </div>
          )}

          {/* Scheduled info box */}
          {trip.status !== "cancelled" && isScheduled && (
            <div className="mt-3 rounded-lg border border-border bg-surface/50 p-3">
              <div className="text-sm text-foreground">
                <span className="font-semibold">Scheduled trip</span> — Date and course shown for planning. Signups will open 30 days before the trip date.
              </div>
            </div>
          )}

          {/* 1) Golf details block */}
          {(courseName || courseText?.title !== "Course TBD") && (
            <div className={isHostedRoundTrip ? "mt-3" : "mt-4"}>
              {/* Primary line: Course name + location */}
              <div className="text-base font-medium text-foreground">
                {courseName || courseText?.title}
                {course?.location && (
                  <span className="text-muted"> · {course.location}</span>
                )}
              </div>
              {/* Secondary line: Tee + format + metrics */}
              {golfDetailsSecondary && (
                <div className="text-sm text-muted mt-1">
                  {golfDetailsSecondary}
                </div>
              )}
            </div>
          )}

          {/* 2) Time block */}
          {isHostedRoundTrip ? (
            <div className={isHostedRoundTrip ? "mt-2" : "mt-3"}>
              <div className="text-sm text-foreground font-medium">
                {formatTripDateLong(trip.date)}
                {meetTime && (
                  <span className="text-muted"> · {meetTime}</span>
                )}
              </div>
            </div>
          ) : (
            <div className="mt-3 space-y-0.5">
              <div className="text-sm text-foreground font-medium">
                {formatTripDateLong(trip.date)}
              </div>
              {meetTime && (
                <div className="text-sm text-foreground">
                  {meetTime}
                </div>
              )}
            </div>
          )}

          {/* 3) Decision logistics block - shown if present (read-only for attendees) */}
          {(meetingPoint || meetTime) && !(trip.createdByMemberId === currentUserId) && (
            <div className="mt-3 space-y-1 text-sm text-foreground">
              {meetingPoint && <div><span className="text-muted">Meet:</span> {meetingPoint}</div>}
            </div>
          )}

          {/* 4) Host indication (calm, secondary) */}
          {trip.createdByMemberName && (
            <div className="mt-2 text-sm text-secondary">
              {trip.createdByMemberId === currentUserId ? "Hosted by you" : `Hosted by ${trip.createdByMemberName}`}
            </div>
          )}

          {/* 5) Trip state block (muted) */}
          {tripStateText && (
            <div className="mt-2 text-sm text-muted">
              {tripStateText}
              {trip.status !== "cancelled" && (
                <span className="ml-2">· {confirmedCountValue} confirmed</span>
              )}
            </div>
          )}

          {/* Temporal cue */}
          {(() => {
            const today = new Date().toISOString().slice(0, 10);
            const isToday = trip.date === today;
            const isClosed = trip.status === "closed";
            
            if (isToday && trip.status !== "cancelled") {
              return (
                <div className="mt-2 text-xs text-muted">Today's the day.</div>
              );
            } else if (isClosed && !isToday && trip.date) {
              const tripDate = new Date(trip.date + "T00:00:00");
              const dayName = tripDate.toLocaleDateString("en-GB", { weekday: "long" });
              return (
                <div className="mt-2 text-xs text-muted">All set — see you on {dayName}.</div>
              );
            }
            return null;
          })()}

          {/* Meet details - hosted rounds only */}
          <section id="meet-details" className="rounded-xl border bg-surface shadow-sm p-4">
            {(() => {
              const canEditMeetDetails = trip.createdByMemberId === currentUserId;
              
              // Hosted round instrument behavior
              if (!canEditMeetDetails) {
                // Non-host view: show read-only or empty state
                const note = (trip.decisionLogistics?.notes || trip.logistics?.notes)?.trim() || null;
                if (!hasMeetDetails && !note) {
                  return (
                    <div>
                      <div className="text-sm font-medium text-foreground mb-1">Meet details</div>
                      <p className="text-xs text-muted">Meet details haven't been added yet.</p>
                    </div>
                  );
                }
                // Show read-only details
                return (
                  <div className="space-y-3">
                    <div className="text-sm font-medium text-foreground">Meet details</div>
                    <div>
                      <div className="text-xs text-muted">Meet time</div>
                      <div className="mt-1 text-sm text-foreground">
                        {meetTimeValue ? meetTimeValue : "—"}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-muted">Where to meet</div>
                      <div className="mt-1 text-sm text-foreground">
                        {meetingPointValue ? meetingPointValue : "—"}
                      </div>
                    </div>
                    {note && (
                      <div>
                        <div className="text-xs text-muted">Note</div>
                        <div className="mt-1 text-sm text-foreground whitespace-pre-wrap">
                          {note}
                        </div>
                      </div>
                    )}
                  </div>
                );
              }
              
              // Host view: show instrument or read-only with edit button
              if (editingMeetDetails) {
                return (
                  <HostedRoundMeetDetailsInstrument
                    trip={trip}
                    currentUserId={currentUserId}
                    supabase={supabase}
                    activeGroupId={activeGroupId}
                    onUpdate={(updatedTrip) => {
                      setTrips((prev) => prev.map((t) => (t.id === trip.id ? updatedTrip : t)));
                      setEditingMeetDetails(false);
                    }}
                  />
                );
              }
              
              // Read-only view with edit button
              const note = (trip.decisionLogistics?.notes || trip.logistics?.notes)?.trim() || null;
              return (
                <>
                  <div className="mb-3 flex items-start justify-between gap-3">
                    <div className="text-sm font-medium text-foreground">Meet details</div>
                    {hasMeetDetails && (
                      <button
                        type="button"
                        onClick={() => setEditingMeetDetails(true)}
                        className="rounded-md border border-border bg-transparent px-3 py-1.5 text-xs font-medium text-foreground hover:bg-surface"
                      >
                        Edit meetup
                      </button>
                    )}
                  </div>
                  <div className="space-y-3">
                    <div>
                      <div className="text-xs text-muted">Meet time</div>
                      <div className="mt-1 text-sm text-foreground">
                        {meetTimeValue ? meetTimeValue : "—"}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-muted">Where to meet</div>
                      <div className="mt-1 text-sm text-foreground">
                        {meetingPointValue ? meetingPointValue : "—"}
                      </div>
                    </div>
                    {note && (
                      <div>
                        <div className="text-xs text-muted">Note</div>
                        <div className="mt-1 text-sm text-foreground whitespace-pre-wrap">
                          {note}
                        </div>
                      </div>
                    )}
                  </div>
                </>
              );
            })()}
          </section>

          {/* RSVP - hosted rounds */}
          <section className="border-t border-border bg-transparent px-1 pt-4">
            <div className="text-sm font-medium text-muted mb-2">RSVP</div>

            {scoringStarted ? (
              <div className="mt-2">
                <div className="text-sm text-foreground">
                  {myEntry?.status === "confirmed" ? "You're playing today." : "You're marked as not playing."}
                </div>
                <div className="mt-1 text-xs text-muted">
                  Scoring has started.
                </div>
              </div>
            ) : (
              <TripRsvpActions
                status={myEntry?.status}
                onJoin={handleImIn}
                onLeave={handleImOut}
                joinDisabled={joinDisabled}
                leaveDisabled={locked}
                showJoin={trip.status === "open" && !isScheduled}
                showMicrocopy={true}
                neutralLeaveButton={true}
              />
            )}
          </section>
        </>
      )}

      {/* 3) Logistics block (single coherent group) - hidden for hosted rounds, also hidden for group trips when Zone C is disabled */}
      {!isHostedRound(trip) && (isGroupTripPage ? SHOW_ZONE_C_GROUP_TRIPS : true) && (trip.logistics?.meetingPoint || trip.ferry || trip.logistics?.itineraryDetails || trip.logistics?.ferryDetails || trip.logistics?.notes) && (
        <section className="rounded-xl border bg-surface p-5 shadow-sm">
          <div className="mb-3 text-sm font-medium text-muted">Logistics</div>

          <div className="space-y-2 text-sm text-foreground">
            {trip.logistics?.meetingPoint && (
              <div>{trip.logistics.meetingPoint}</div>
            )}

            {trip.ferry && (
              <div>{trip.ferry}</div>
            )}

            {(trip.logistics?.itineraryDetails || trip.logistics?.ferryDetails) && (
              <div className="text-sm text-foreground whitespace-pre-wrap">
                {trip.logistics?.itineraryDetails || trip.logistics?.ferryDetails}
              </div>
            )}

            {trip.logistics?.notes && (
              <div className="text-sm text-foreground whitespace-pre-wrap">
                {trip.logistics.notes}
              </div>
            )}
          </div>
        </section>
      )}

      {/* Results section - hidden for group trips when Zone C is disabled */}
      {(!isGroupTripPage || SHOW_ZONE_C_GROUP_TRIPS) && (
      <section className="border-t border-border bg-transparent px-1 pt-4">
        <div className={`text-sm font-medium ${isHostedRoundTrip ? "text-muted mb-1.5" : "text-muted mb-2"}`}>Results</div>

        {trip.result ? (
          <div className="flex items-center justify-between gap-3">
            <div className={`text-sm ${isHostedRoundTrip ? "text-muted" : "text-foreground"}`}>Published</div>
            <Link
              href={`/results/${tripIdSafe}`}
              className={`rounded-md border px-3 py-2 text-sm hover:bg-background ${isHostedRoundTrip ? "bg-transparent text-muted border-border" : "bg-surface text-foreground"}`}
            >
              View Results →
            </Link>
          </div>
        ) : (
          <div className={`text-sm ${isHostedRoundTrip ? "text-muted" : "text-muted"}`}>Not published yet.</div>
        )}
      </section>
      )}

      {/* Attendees section - hidden for group trips when Zone C is disabled */}
      {(!isGroupTripPage || SHOW_ZONE_C_GROUP_TRIPS) && (
      <section className="border-t border-border bg-transparent px-1 pt-4">
        <div className="mb-3 flex items-center justify-between gap-3">
          <div className="text-sm font-medium text-muted">Attendees</div>
          
          {/* Profile photo avatars (up to 4, overlapping slightly) */}
          {attendeeProfilePhotos.length > 0 && (
            <div className="flex items-center -space-x-2">
              {attendeeProfilePhotos.slice(0, 4).map((attendee) => (
                <div
                  key={attendee.memberId}
                  className="relative h-7 w-7 shrink-0 rounded-full border-2 border-surface bg-background overflow-hidden"
                  title={attendee.name}
                >
                  {attendee.photoUrl ? (
                    <img
                      src={attendee.photoUrl}
                      alt={attendee.name}
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center text-[10px] font-medium text-muted">
                      {getInitials(attendee.name)}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {isHostedRoundTrip ? (
          <>
            <div className="text-sm text-foreground mb-3">
              <span className="font-semibold">{confirmed.length}</span> confirmed
              {waitlist.length ? (
                <>
                  {" "}
                  · <span className="font-semibold">{waitlist.length}</span> waitlist
                </>
              ) : null}
            </div>

            <div className="space-y-1.5">
              {hostedRoundAttendees
                .filter((a) => !a.isWaitlist)
                .map((attendee) => {
                  const handicap = attendee.handicap ?? attendee.handicapForTrip ?? null;
                  const displayName = attendee.name;
                  
                  return (
                    <div
                      key={attendee.memberId || attendee.name}
                      className="flex items-center justify-between gap-3 rounded-lg border border-border bg-surface p-3"
                    >
                      {/* Left: Photo + Name */}
                      <div className="flex items-center gap-3 min-w-0 flex-1">
                        {attendee.photoUrl ? (
                          <img
                            src={attendee.photoUrl}
                            alt={displayName}
                            className="h-12 w-12 flex-shrink-0 rounded-full object-cover border border-border"
                          />
                        ) : (
                          <div className="h-12 w-12 flex-shrink-0 rounded-full bg-background border border-border flex items-center justify-center text-sm font-medium text-muted">
                            {displayName.charAt(0).toUpperCase()}
                          </div>
                        )}
                        <div className="min-w-0 flex-1">
                          <div className="text-sm font-medium text-foreground truncate">
                            {displayName}
                          </div>
                        </div>
                      </div>

                      {/* Right: Handicap */}
                      <div className="flex-shrink-0">
                        <div className="text-sm text-muted">
                          {handicap !== null && handicap !== undefined ? `HCP ${handicap}` : "HCP —"}
                        </div>
                      </div>
                    </div>
                  );
                })}
              
              {hostedRoundAttendees.filter((a) => a.isWaitlist).length > 0 && (
                <>
                  <div className="pt-2 text-sm font-medium text-muted">Waitlist</div>
                  {hostedRoundAttendees
                    .filter((a) => a.isWaitlist)
                    .map((attendee) => {
                      const handicap = attendee.handicap ?? attendee.handicapForTrip ?? null;
                      const displayName = attendee.name;
                      
                      return (
                        <div
                          key={attendee.memberId || attendee.name}
                          className="flex items-center justify-between gap-3 rounded-lg border border-border bg-surface p-3"
                        >
                          {/* Left: Photo + Name */}
                          <div className="flex items-center gap-3 min-w-0 flex-1">
                            {attendee.photoUrl ? (
                              <img
                                src={attendee.photoUrl}
                                alt={displayName}
                                className="h-12 w-12 flex-shrink-0 rounded-full object-cover border border-border"
                              />
                            ) : (
                              <div className="h-12 w-12 flex-shrink-0 rounded-full bg-background border border-border flex items-center justify-center text-sm font-medium text-muted">
                                {displayName.charAt(0).toUpperCase()}
                              </div>
                            )}
                            <div className="min-w-0 flex-1">
                              <div className="text-sm font-medium text-foreground truncate">
                                {displayName}
                              </div>
                            </div>
                          </div>

                          {/* Right: Handicap */}
                          <div className="flex-shrink-0">
                            <div className="text-sm text-muted">
                              {handicap !== null && handicap !== undefined ? `HCP ${handicap}` : "HCP —"}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                </>
              )}
            </div>
          </>
        ) : (
          <>
            <div className="text-sm text-foreground">
              <span className="font-semibold">{confirmed.length}</span> confirmed
              {waitlist.length ? (
                <>
                  {" "}
                  · <span className="font-semibold">{waitlist.length}</span> waitlist
                </>
              ) : null}
            </div>

            <div className="mt-3 grid gap-2">
              {confirmed.map((a, idx) => (
                <div key={a.name} className="flex items-center justify-between rounded-md border px-3 py-2 text-sm">
                  <span>
                    {idx + 1}. {a.name}
                  </span>
                  <span className="text-xs text-muted">
                    {a.handicapForTrip !== undefined && a.handicapForTrip !== null ? `HCP ${a.handicapForTrip}` : ""}
                  </span>
                </div>
              ))}

              {waitlist.length ? <div className="pt-2 text-sm font-medium text-muted">Waitlist</div> : null}

              {waitlist.map((a, idx) => (
                <div key={a.name} className="flex items-center justify-between rounded-md border px-3 py-2 text-sm">
                  <span>
                    {idx + 1}. {a.name}
                  </span>
                  <span className="text-xs text-muted">
                    {a.handicapForTrip !== undefined && a.handicapForTrip !== null ? `HCP ${a.handicapForTrip}` : ""}
                  </span>
                </div>
              ))}
            </div>
          </>
        )}
      </section>
      )}
      </div>

      <ConfirmModal
        isOpen={confirmModal.isOpen}
        title={confirmModal.title}
        message={confirmModal.message}
        confirmLabel={confirmModal.title === "Leave this trip?" ? "Leave" : "Yes"}
        cancelLabel={confirmModal.title === "Leave this trip?" ? "Cancel" : "No"}
        confirmVariant={confirmModal.title === "Leave this trip?" ? "danger" : "primary"}
        onConfirm={confirmModal.onConfirm}
        onCancel={confirmModal.onCancel}
      />

      <PromptModal
        isOpen={promptModal.isOpen}
        title={promptModal.title}
        message={promptModal.message}
        defaultValue={promptModal.defaultValue}
        placeholder={promptModal.placeholder}
        confirmLabel="OK"
        cancelLabel="Cancel"
        onConfirm={promptModal.onConfirm}
        onCancel={promptModal.onCancel}
      />
    </div>
  );
}
