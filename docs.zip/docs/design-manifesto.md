# Day Fore It Design Manifesto

## Philosophy: Instruments, Not Dashboards

Day Fore It is not a dashboard. It is a collection of instruments that surface the next golf moment with clarity and intention.

An instrument shows state, not statistics. It answers "What's next?" not "What happened?". It is calm, legible, and confident. It does not compete for attention.

## Modes vs Pages

Day Fore It operates in two distinct modes:

### Home Mode
Home is the landing instrument. It surfaces:
- The next golf moment (trip, round, or game)
- Current handicap as state
- A single primary action: "Host a round"

Home does not show:
- Multiple competing CTAs
- Cards, shadows, or stacked panels
- Historical data or statistics
- Secondary or tertiary actions

### GameDay Mode
GameDay is the active playing instrument. It surfaces:
- Current hole and scoring state
- Flight and participant context
- Next action for the current moment

GameDay does not show:
- Navigation to other trips
- Administrative controls
- Historical comparisons
- Competing primary actions

## Hard Rules

### Visual Hierarchy
1. One primary surface per mode
2. No card chrome: no borders, no shadows, no rounded panels
3. Typography creates hierarchy, not decoration
4. Spacing is intentional, not decorative

### Interaction
1. One primary action per screen
2. No dead ends: every screen has a next action, a skip, and an exit
3. Fail-fast validation: errors are clear and immediate
4. No competing actions: if two actions exist, one is primary, one is secondary

### Content
1. Show only what's needed for the current moment
2. Defaults first, ask later, never ask twice
3. No placeholders or empty states that feel like errors
4. Calm copy: "No upcoming rounds" not "You don't have any trips yet"

### GameDay vs Home
1. Home is for discovery and preparation
2. GameDay is for active play
3. These modes do not overlap in purpose or presentation
4. Navigation between modes is explicit and intentional

## Apple-Level Simplicity

Simple is hard. Simple means:
- Removing everything that doesn't serve the moment
- Making the right thing obvious
- Trusting the user to understand without explanation
- Using space, not decoration, to create hierarchy

Simple does not mean:
- Minimal for minimal's sake
- Hiding functionality
- Reducing information density arbitrarily
- Making things smaller or less visible

## Implementation Principles

### Code
- Shared route builders prevent broken navigation
- API contracts enforce fail-fast validation
- Server auth helpers ensure consistent authorization
- No hardcoded strings for paths or API endpoints

### Design
- Instruments use large, legible typography
- State is shown as numbers, not charts
- Actions are buttons, not links disguised as buttons
- Empty states are calm, not apologetic

### Interaction
- Loading states are minimal: "Loading…" not spinners
- Errors are clear: "Failed to start GameDay" not generic messages
- Success is implicit: navigation happens, no confirmation needed
- Validation happens before submission, not after

## The North Star

Every design decision should answer: "Does this surface the next golf moment with clarity and intention?"

If the answer is no, remove it.

If the answer is yes but it competes with something else, make one primary and one secondary.

If the answer is yes and it's the only thing, make it dominant.

This is the instrument-first philosophy. This is Day Fore It.
